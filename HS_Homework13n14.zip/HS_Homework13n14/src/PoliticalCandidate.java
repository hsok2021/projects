
public class PoliticalCandidate {

	public void run() {
		System.out.println("A political candidate runs for office.");
	}
	
}
