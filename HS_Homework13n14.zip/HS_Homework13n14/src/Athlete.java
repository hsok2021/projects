
public class Athlete implements Runner {
	
	public void run() {
		System.out.println("An athlete might run in a race, or in a game like soccer.");
	}

}
