
public class Machine {

	public void run() {
		System.out.println("When a machine is running, it is operating.");
	}
	
}
