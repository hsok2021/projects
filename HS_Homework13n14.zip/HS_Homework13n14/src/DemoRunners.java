/*
Author: Hunter Sokolis
Date: 11/27/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Tests 3 different implementations of Runner which all output different results.
 */

public class DemoRunners {
	public static void main(String[] args) {
		Athlete ath = new Athlete();
		PoliticalCandidate cand = new PoliticalCandidate();
		Machine mach = new Machine();
		mach.run();
		ath.run();
		cand.run();
	}
}
