
interface Runner {
	public void run();
}
