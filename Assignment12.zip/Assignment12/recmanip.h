// Creation of recmanip.h header file
#ifndef RECMANIP_H
#define RECMANIP_H

#include <vector>
#include <fstream>
#include "cost.h"

int parse_account(std::fstream& recordFile, std::vector<Cost>& costStore);
double sum_accounts(std::vector<Cost>accountList);

#endif