// Creation of cost.h header file
#ifndef COST_H
#define COST_H

#include <string>

struct Cost {
	std::string description;
	double amount;
	int itemNum;
};

#endif