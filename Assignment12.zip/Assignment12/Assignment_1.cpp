/*
Application Name: Storage Inventory Database
Assignment Number: Unit 12 Assignment 1
Version: 1.0
Description: Prompts the user for a file to read, reads the file and stores its data in a vector of data structures, and then calculates the sum
             of the costs of every data structure in the vector.
Input: String
Output: String, integer, double

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 11/9/2022
*/

#include <iostream>
#include <fstream>
#include <vector>
#include "cost.h"
#include "recmanip.h"
using namespace std;

int main()
{
    // Variable declaration
    vector<Cost> storedCost;
    string userFilename;
    string ch;
    int parseResult = 1;

    // Initial user prompt
    cout << "This is the Storage Inventory Database." << endl;
    cout << "Please choose the desired database file you wish to open. (Main database file is located at \"../costfile.txt\")" << endl;
    cin >> userFilename;

    // Attempt to open user-selected file
    fstream recordData;
    recordData.open(userFilename, ios::in | ios::out);
    // File validation
    while (!recordData) {
        cout << "The file by the name of " << userFilename << " does not appear to exist. Please try again." << endl;
        cin >> userFilename;
        recordData.open(userFilename, ios::in | ios::out);
    }

    // Pass through file and call parse_account
    while (parseResult == 1) {
        parseResult = parse_account(recordData, storedCost);
    }

    // Call sum_accounts
    cout << "The sum of the cost of all of the items is " << sum_accounts(storedCost) << "$." << endl;

    // Close the file
    recordData.close();
}