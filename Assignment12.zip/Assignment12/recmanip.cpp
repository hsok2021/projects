#include <fstream>
#include <string>
#include <vector>
#include <cctype>
#include "cost.h"

// Parses through a file to add a Cost to a vector of Costs
int parse_account(std::fstream &recordFile, std::vector<Cost> &costStore) {
	// Initialize parseCost, fileLine, lineCount, isRecord, costDesc, costUnCAmt, costUnCItemNum, costAmt, and costItemNum
	Cost parseCost;
	std::string fileLine;
	int lineCount = 0;
	bool isRecord = false;
	std::string costDesc;
	std::string costUnCAmt;
	std::string costUnCItemNum;
	double costAmt;
	int costItemNum;

	// Determine whether or not line can be read from a file
	if (getline(recordFile, fileLine, '\n')) {

		// Pass through the characters contained in fileLine, which is parsed from the file, to determine whether or not it is a real record
		for (int i = 0; i < fileLine.length(); i++) {
			if (isdigit(fileLine[i])) {
				isRecord = true;
			}
		}

		// Exit the function if the line is not a real record
		if (isRecord == false) {
			return 1;
		}

		// Continue the function if the line is a real record
		else {

			// Step through the first field in the record until met by whitespace (description)
			while (!isspace(fileLine[lineCount]) && lineCount < fileLine.length()) {
				costDesc += fileLine[lineCount];
				lineCount++;
			}

			// Step through whitespace separating the first and second fields
			while (isspace(fileLine[lineCount]) && lineCount < fileLine.length()) {
				lineCount++;
			}

			// Step through the second field in the record until met by whitespace (amount)
			while (!isspace(fileLine[lineCount]) && lineCount < fileLine.length()) {
				costUnCAmt += fileLine[lineCount];
				lineCount++;
			}

			// Step through whitespace separating the second and third fields
			while (isspace(fileLine[lineCount]) && lineCount < fileLine.length()) {
				lineCount++;
			}

			// Step through the third field in the record until met by whitespace (itemNum)
			while (!isspace(fileLine[lineCount]) && lineCount < fileLine.length()) {
				costUnCItemNum += fileLine[lineCount];
				lineCount++;
			}

			// Convert unconverted costUnCAmt and costUnCItemNum to double and integer, respectively
			costAmt = stod(costUnCAmt);
			costItemNum = stoi(costUnCItemNum);

			// Populate parseCost with costDesc, costAmt, and costItemNum and push back Cost structure to costStore
			parseCost = { costDesc, costAmt, costItemNum };
			costStore.push_back(parseCost);
			return 1;
		}
	}

	// If line cannot be read, exit the function
	else {
		return 0;
	}
}

// Calculates the sum of the amounts found in a vector of Costs
double sum_accounts(std::vector<Cost>accountList) {
	// Initialize sum
	double sum = 0.0;

	// Pass through array of Costs to accumulate amounts
	for (int i = 0; i < accountList.size(); i++) {
		sum += accountList[i].amount;
	}

	// Calculate sum of amounts
	sum /= static_cast<double>(accountList.size());

	// Return sum
	return sum;
}