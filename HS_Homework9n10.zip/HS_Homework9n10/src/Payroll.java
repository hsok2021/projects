/*
Author: Hunter Sokolis
Date: 10/30/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: creates Payroll class with private members name, pay, hours, totalPay, constructors Payroll(), Payroll(String,
double, int), Payroll(String), getters getName(), getPay(), getHours(), setters setName(), setPay(), setHours(), computePay()
which computes the total pay, and toString() that returns a String that includes information from the specified Payroll
instance.
 */

public class Payroll {
	private String name = "";
	private double pay = 0.0;
	private int hours = 0;
	private double totalPay = 0.0;
	
	//constructors
	public Payroll() {
		this.name = "";
		this.pay = 0.0;
		this.hours = 0;
		this.totalPay = 0.0;
	}
	public Payroll(String name, double pay, int hours) {
		this.name = name;
		this.pay = pay;
		this.hours = hours;
	}
	public Payroll(String name) {
		this.name = name;
	}
	
	//getters
	public String getName() {
		return this.name;
	}
	public double getPay() {
		return this.pay;
	}
	public int getHours() {
		return this.hours;
	}
	
	//setters
	public void setName(String name) {
		this.name = name;
	}
	public void setPay(double pay) {
		this.pay = pay;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	
	public void computePay() {
		totalPay = pay * hours;
	}
	public String toString() {
		String toPrint = "";
		toPrint += "Employee name: " + this.name + "\n";
		toPrint += "Pay rate: $" + String.format("%.2f", this.pay) + "\n";
		toPrint += "Hours worked: " + this.hours + "\n";
		toPrint += "Total pay: $" + String.format("%.2f", this.totalPay) + "\n";
		return toPrint;
	}
}
