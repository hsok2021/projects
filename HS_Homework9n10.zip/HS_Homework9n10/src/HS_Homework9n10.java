
public class HS_Homework9n10 {
	public static void main(String[] args) {
		Payroll[] test = new Payroll[5];
		// random creation
		for (int i = 0; i < test.length - 2; i++) {
			test[i] = new Payroll(("Employee " + (i + 1)), ((Math.random() * 10.0) + 20.0), ((int)((Math.random() * 3.0) + 4.0)));
		}
		test[3] = new Payroll();
		test[4] = new Payroll("John");
		
		test[2].setHours(8);
		test[4].setName("Jerry");
		test[1].setPay(35);
		
		System.out.println(test[3].getHours());
		System.out.println(test[0].getName());
		System.out.println(test[4].getPay());
		
		for (int i = 0; i < test.length; i++) {
			test[i].computePay();
		}
		
		for (int i = 0; i < test.length; i++) {
			System.out.println(test[i].toString());
		}
	}
}
