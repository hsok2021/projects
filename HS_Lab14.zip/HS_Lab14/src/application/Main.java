/*
Author: Hunter Sokolis
Date: 11/27/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program will display the text "WELCOME TO JAVA" in a circle.
 */

package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.*;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		
		try {
			Pane pane = new Pane();
			Font font = Font.font("Times New Roman", FontWeight.BOLD, FontPosture.REGULAR, 25);
			String toDisplay = "WELCOME TO JAVA";
			pane.setPrefSize(200, 200);
			double center = pane.getPrefWidth() / 2;
			double radius = 50;
			double rotation = 0;
			
			//loop
			for (int i = 0; i < toDisplay.length(); i++) {
				double x = center + Math.cos(Math.toRadians(rotation)) * radius;
				double y = center + Math.sin(Math.toRadians(rotation)) * radius;
				Text text = new Text(x, y, toDisplay.charAt(i) + "");
				text.setFont(font);
				text.setRotate(rotation + 90);
				pane.getChildren().add(text);
				rotation += 360 / (toDisplay.length() + 1);
			}
			
			Scene scene = new Scene(pane, 200, 200);
			primaryStage.setTitle("circle");
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
