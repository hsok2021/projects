// Include files
#include <deque>
#include <iostream>
#include <queue>
#include <stack>
#include <string>

int main()
{
    // Your passcodes
    std::string stackString = "GI7DE1GINJTHGN";
    std::string queueString = "OANRBIONWDYG";
    std::string dequeString = "01IM45RWXH";

    // Create an empty stack
    // Forward iterate through stackString and push each character onto your stack

    std::stack<char> testStack;
    for (char i : stackString) {
        testStack.push(i);
    }

    // Create an empty queue
    // Forward iterate through queueString and push each character into your queue

    std::queue<char> testQueue;
    for (char i : queueString) {
        testQueue.push(i);
    }

    // Create an empty deque
    // Forward iterate through dequeString and push each character into the front of your deque

    std::deque<char> testDeque;
    for (char i : dequeString) {
        testDeque.push_front(i);
    }

    // Your command list
    std::string commands = "2F145IF41268Q76963G5W651761W2W53G67JR1523F7W87897896769W85A4D2W85W7942357H87E8R77654";

    // Forward iterate through the commands string and do the following for each character you find:
        // 1 = Pop the queue
        // 2 = Pop the front of the deque
        // 3 = Pop the back of the deque
        // 4 = Pop the stack
        // 5 = COPY the top of the stack into the queue
        // 6 = MOVE the front of the queue onto the stack
        // 7 = COPY the front of the queue into the queue
        // 8 = MOVE the top of the stack into the back of the deque
        // ANYTHING ELSE = Do nothing with all of the three data structures
        
        //  COPY means to get data from one data structure and copy it into another (maybe the same one)
        //  - One data structure will keep all its elements
        //  - The other data structure will gain an element
        //  MOVE means to remove data from one structure and place it into another (maybe the same one)
        //  - One data structure will lose an element
        //  - The other data structure will gain an element


    for (char i : commands) {
        switch (i) {
        case '1':
            testQueue.pop();
            break;
        case '2':
            testDeque.pop_front();
            break;
        case '3':
            testDeque.pop_back();
            break;
        case '4':
            testStack.pop();
            break;
        case '5':
            testQueue.push(testStack.top());
            break;
        case '6':
            testStack.push(testQueue.front());
            testQueue.pop();
            break;
        case '7':
            testQueue.push(testQueue.front());
            break;
        case '8':
            testDeque.push_back(testStack.top());
            testStack.pop();
            break;
        }
    }

    // Keep this printout to the console
    std::cout << "Statistically speaking... What time might it be right now?" << std::endl;

    // The deque will now have the secret phrase, so forward iterate through it and print it out

    for (char i : testDeque) {
        std::cout << i;
    }

    return 0;
}