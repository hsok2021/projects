/*
Author: Hunter Sokolis
Date: 11/20/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program prompts the user for a decimal number and then converts that number into a fraction and displays it.
 */

import java.math.BigInteger;
import java.util.*;

public class Test {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter a decimal number: ");
		double dec = input.nextDouble();
		input.close();
		
		//convert
		String integer = Integer.toString((int)dec);
		String temp = Double.toString(dec);
		double decimal = Double.valueOf(temp.substring(temp.indexOf(".")));
		long precision = (long)Math.pow(10, 10);
		double gcd = gcd(Math.round(decimal * precision), precision);
		String numerator = Integer.toString((int)((decimal * precision) / gcd));
		String denominator = Integer.toString((int)(precision / gcd));
		Rational frac1 = new Rational(new BigInteger(integer), new BigInteger("1"));
		Rational frac2 = new Rational(new BigInteger(numerator), new BigInteger(denominator));
				
		System.out.print(frac1.add(frac2));
		
	}
	
	static long gcd(long a, long b)
	{
	    if (a == 0)
	        return b;
	    else if (b == 0)
	        return a;
	    if (a < b)
	        return gcd(a, b % a);
	    else
	        return gcd(b, a % b);
	}
}
