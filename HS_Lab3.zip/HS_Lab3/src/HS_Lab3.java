import java.util.*;

/*
Author: Hunter Sokolis
Date: 9/11/2023
Course: CIS-2571
Instructor: Mariusz Gladys

Description: Program will prompt user to enter 0, 1, or 2 corresponding to rock, paper, or scissors. The computer
will then select a number between 0 and 2. Depending on the two selected numbers, you either win, lose, tie, or are
invalidated.
 */

public class HS_Lab3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int cpuChoice = (int)(Math.random() * 3);
		int userChoice = 0;
		
		System.out.print("Input 0 (Rock), 1 (Paper), or 2 (Scissors): ");
		userChoice = input.nextInt();
		input.close();
		
		// user output
		if (userChoice == 0) {
			System.out.print("You chose rock and the computer chose ");
		}
		else if (userChoice == 1) {
			System.out.print("You chose paper and the computer chose ");
		}
		else if (userChoice == 2) {
			System.out.print("You chose scissors and the computer chose ");
		}
		else {
			System.out.print("You chose an impossible option and the computer chose ");
		}
		
		// computer output
		if (cpuChoice == 0) {
			System.out.print("rock. ");
		}
		else if (cpuChoice == 1) {
			System.out.print("paper. ");
		}
		else {
			System.out.print("scissors. ");
		}
		
		// result output
		if ( (cpuChoice == 0 && userChoice == 0)   ||   (cpuChoice == 1 && userChoice == 1)
				||   (cpuChoice == 2 && userChoice == 2) ) {
			System.out.println("You tied.");
		}
		else if ( (cpuChoice == 0 && userChoice == 2)   ||   (cpuChoice == 1 && userChoice == 0)
				||   (cpuChoice == 2 && userChoice == 1) ) {
			System.out.println("You lose.");
		}
		else if ( (cpuChoice == 0 && userChoice == 1)   ||   (cpuChoice == 1 && userChoice == 2)
				||   (cpuChoice == 2 && userChoice == 0) ) {
			System.out.println("You win!");
		}
		else {
			System.out.println("Don't try to cheat me!");
		}
		
	}
}
