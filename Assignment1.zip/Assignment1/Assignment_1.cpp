/*
Hunter Sokolis
8/23/2022
CIS2541
Program will calculate total price of bought items including sales tax for state
*/

#include <iostream>
using namespace std;

int main()
{
	// Initialization
	double price, tax, total;
	int amount;

	// Input price of item
	cout << "What is the price of the item that you wish to purchase? ";
	cin >> price;

	// Input item quantity
	cout << "How much of this item do you wish to purchase? ";
	cin >> amount;

	// Input sales tax for state and properly process
	cout << "What is the sales tax percentage for your state? (Example input: 6.25) ";
	cin >> tax;
	tax = 1 + (tax / 100);

	// Calculate total based on inputs and return total
	total = (price * amount) * tax;
	cout << "Your total comes out to $" << total << "." << endl;

	return 0;
}
