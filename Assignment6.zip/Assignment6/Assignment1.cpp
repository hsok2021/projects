/*
Application Name: EduCalc
Assignment Number: Unit 6 Assignment 1
Version: 1.0
Description: Prompts user for answers to math questions to addition, subtraction, multiplication, divison, and modulus problems. Answers will be recorded as
             right or wrong, and a summary will be given when the user decides to exit the question category.
Input: Double, char
Output: Integer, double, string

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/26/2022
*/

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

// Function prototyping

int calcAdd(int, int);
int calcSubtract(int, int);
int calcMultiply(int, int);
double calcDivide(int, int);
int calcModulo(int, int);
void displayMenu();

int main()
{

    // Data storage

    unsigned long long seed = time(0);
    srand(seed);

    char userInput;
    double guess, result;
    int qRight, qWrong, qCount;

    // User prompt

    displayMenu();
    do {
        cin >> userInput;
    } while ((userInput == 'Exit') && (static_cast<int>(userInput) < 49 || static_cast<int>(userInput) > 53));

    // Loop question selection

    while (userInput != 'Exit') {
        switch (userInput) {

            // Addition

            case '1':

                // Add data storage

                qRight = 0;
                qWrong = 0;
                qCount = 0;
                result = calcAdd((1 + (rand() % 20)), (1 + (rand() % 20)));
                cin >> guess;

                // Add loop

                while (guess != -1) {
                    if (guess == result) {
                        cout << "Very good!" << endl;
                        result = calcAdd((1 + (rand() % 20)), (1 + (rand() % 20)));
                        cin >> guess;
                        qRight++;
                        qCount++;
                    }
                    else {
                        cout << "No. Please try again." << endl;
                        cin >> guess;
                        qWrong++;
                    }
                }

                // Add summary

                cout << "Addition problems completed: " << qCount << endl;
                cout << "Number of times answered correctly: " << qRight << endl;
                cout << "Number of times answered incorrectly: " << qWrong << endl;

                break;

            // Subtraction

            case '2':

                // Sub data storage

                qRight = 0;
                qWrong = 0;
                qCount = 0;
                result = calcSubtract((1 + (rand() % 20)), (1 + (rand() % 20)));
                cin >> guess;

                // Sub loop

                while (guess != -1) {
                    if (guess == result) {
                        cout << "Very good!" << endl;
                        result = calcSubtract((1 + (rand() % 20)), (1 + (rand() % 20)));
                        cin >> guess;
                        qRight++;
                        qCount++;
                    }
                    else {
                        cout << "No. Please try again." << endl;
                        cin >> guess;
                        qWrong++;
                    }
                }

                // Sub summary

                cout << "Subtraction problems completed: " << qCount << endl;
                cout << "Number of times answered correctly: " << qRight << endl;
                cout << "Number of times answered incorrectly: " << qWrong << endl;

                break;

            // Multiplication

            case '3':

                // Mult data storage

                qRight = 0;
                qWrong = 0;
                qCount = 0;
                result = calcMultiply((1 + (rand() % 20)), (1 + (rand() % 20)));
                cin >> guess;

                // Mult loop

                while (guess != -1) {
                    if (guess == result) {
                        cout << "Very good!" << endl;
                        result = calcMultiply((1 + (rand() % 20)), (1 + (rand() % 20)));
                        cin >> guess;
                        qRight++;
                        qCount++;
                    }
                    else {
                        cout << "No. Please try again." << endl;
                        cin >> guess;
                        qWrong++;
                    }
                }

                // Mult summary

                cout << "Multiplication problems completed: " << qCount << endl;
                cout << "Number of times answered correctly: " << qRight << endl;
                cout << "Number of times answered incorrectly: " << qWrong << endl;

                break;

            // Division

            case '4':

                // Div data storage

                qRight = 0;
                qWrong = 0;
                qCount = 0;
                result = calcDivide((1 + (rand() % 20)), (1 + (rand() % 20)));
                cin >> guess;

                // Div loop

                while (guess != -1) {
                    if (static_cast<double>(guess) == result) {
                        cout << "Very good!" << endl;
                        result = calcDivide((1 + (rand() % 20)), (1 + (rand() % 20)));
                        cin >> guess;
                        qRight++;
                        qCount++;
                    }
                    else {
                        cout << "No. Please try again." << endl;
                        cin >> guess;
                        qWrong++;
                    }
                }

                // Div summary

                cout << "Division problems completed: " << qCount << endl;
                cout << "Number of times answered correctly: " << qRight << endl;
                cout << "Number of times answered incorrectly: " << qWrong << endl;

                break;

            // Modulus

            case '5':

                // Mod data storage

                qRight = 0;
                qWrong = 0;
                qCount = 0;
                result = calcModulo((1 + (rand() % 20)), (1 + (rand() % 20)));
                cin >> guess;

                // Mod loop

                while (guess != -1) {
                    if (guess == result) {
                        cout << "Very good!" << endl;
                        result = calcModulo((1 + (rand() % 20)), (1 + (rand() % 20)));
                        cin >> guess;
                        qRight++;
                        qCount++;
                    }
                    else {
                        cout << "No. Please try again." << endl;
                        cin >> guess;
                        qWrong++;
                    }
                }

                // Mod summary

                cout << "Remainder problems completed: " << qCount << endl;
                cout << "Number of times answered correctly: " << qRight << endl;
                cout << "Number of times answered incorrectly: " << qWrong << endl;

                break;
            default:
                return 0;
        }

        // Menu re-display

        displayMenu();
        do {
            cin >> userInput;
        } while ((userInput == 'Exit') && (static_cast<int>(userInput) < 49 || static_cast<int>(userInput) > 53));
    }
}

// Calculation functions

// Addition

int calcAdd(int num1, int num2) {
    int result = num1 + num2;
    cout << "What is " << num1 << " plus " << num2 << "? (Enter -1 to exit)" << endl;
    return result;
}

// Subtraction

int calcSubtract(int num1, int num2) {
    int result = num1 - num2;
    cout << "What is " << num1 << " minus " << num2 << "? (Enter -1 to exit)" << endl;
    return result;
}

// Multiplication

int calcMultiply(int num1, int num2) {
    int result = num1 * num2;
    cout << "What is " << num1 << " times " << num2 << "? (Enter -1 to exit)" << endl;
    return result;
}

// Division

double calcDivide(int num1, int num2) {
    double result = num1 / static_cast<double>(num2);
    result *= 100;
    result = round(result);
    result = static_cast<int>(result);
    result /= 100;
    cout << "What is " << num1 << " divided by " << num2 << "? (Round to two decimal places) (Enter -1 to exit)" << endl;
    return result;
}

// Modulus

int calcModulo(int num1, int num2) {
    int result = num1 % num2;
    cout << "What is the remainder of " << num1 << " divided by " << num2 << "? (Enter -1 to exit)" << endl;
    return result;
}

// Display functions

// Menu display

void displayMenu() {
    cout << "Menu:" << endl;
    cout << "Enter \'1\' for addition" << endl;
    cout << "Enter \'2\' for subtraction" << endl;
    cout << "Enter \'3\' for multiplication" << endl;
    cout << "Enter \'4\' for division" << endl;
    cout << "Enter \'5\' for modulus" << endl;
    cout << "Enter \'Exit\' to exit" << endl;
}