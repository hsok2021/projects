/*
Author: Hunter Sokolis
Date: 11/13/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Reads a file that contain's Lincoln's 1861 address and then attempts to determine the amount of words that it
contains.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class HS_Homework11n12 {
	public static void main(String[] args) {
		File file = new File("1861-Lincoln.txt");
		Scanner input = null;
		try {
			input = new Scanner(file);
		} catch (FileNotFoundException ex) {
			System.out.println("File not found");
		}
		
		int wordCount = 0;
		while (input.hasNext()) {
			wordCount++;
			input.next();
		}
		System.out.println("Lincoln's 1861 address contains " + wordCount + " words.");
	}
}