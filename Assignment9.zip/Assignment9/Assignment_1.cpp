/*
Application Name: Student Surveying Statistics
Assignment Number: Unit 9 Assignment 1
Version: 1.0
Description: Asks a user to input the number of students surveyed and dynamically allocates a portion of memory for the creation of an array of
             surveyees that the user will then input the amount of movies watched per surveyee for. The program will then calculate the average,
             median, and mode of the surveyees.
Input: Integer
Output: Integer

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 10/23/2022
*/

#include <iostream>
#include <vector>
using namespace std;

// Prototyping
void calcAverage(int [], int);
void calcMedian(int [], int);
void calcMode(int [], int);

int main()
{
    // Initialize numStudents
    int numStudents = 0;

    // Initial user prompt
    cout << "Welcome to the student survey statistics program!" << endl;
    cout << "How many students were surved?" << endl;
    do {
        cin >> numStudents;
        if (numStudents < 1) {
            cout << "It appears that your input was incorrect. Please re-enter your input without a negative number or zero." << endl;
        }
    } while (numStudents < 1);

    // Define surveyees
    int* surveyees = new int[numStudents];

    // Populate surveyees
    for (int i = 0; i < numStudents; i++) {
        cout << "How many movies did student " << (i + 1) << " watch?" << endl;
        do {
            cin >> surveyees[i];
            if (surveyees[i] < 0) {
                cout << "It appears that your input was incorrect. Please re-enter your input without a negative number." << endl;
            }
        } while (surveyees[i] < 0);
    }

    // Calculate average, median, and mode
    calcAverage(surveyees, numStudents);
    calcMedian(surveyees, numStudents);
    calcMode(surveyees, numStudents);
    
    // Free memory
    delete[] surveyees;

    return 0;

}

// Calculate average movies watched
void calcAverage(int toBeAveraged[], int averageNum) {
    // Initialize average
    int average = 0;

    // Sum average
    for (int i = 0; i < averageNum; i++) {
        average += toBeAveraged[i];
    }

    // Calculate average and display
    average /= averageNum;
    cout << "The average number of movies watched is " << average << " movie(s)." << endl;
}

// Calculate median of movies watched
void calcMedian(int toBeMedian[], int medianNum) {
    // Initialize largestSort and medianIndex
    int largestSort = 0;
    int medianIndex = 0;

    // Bubble sort toBeMedian
    for (int i = 0; i < medianNum; i++) {
        for (int x = 1; x < medianNum; x++) {
            if (toBeMedian[x] < toBeMedian[x - 1]) {
                largestSort = toBeMedian[x - 1];
                toBeMedian[x - 1] = toBeMedian[x];
                toBeMedian[x] = largestSort;
            }
        }
    }

    // Calculate and display median
    if (medianNum % 2 == 0) {
        medianIndex = medianNum / 2;
        cout << "The median numbers of movies watched were " << toBeMedian[medianIndex - 1] << ", and " << toBeMedian[medianIndex] << " movie(s)." << endl;
    }
    else {
        medianIndex = medianNum / 2;
        cout << "The median of movies watched was " << toBeMedian[medianIndex] << " movie(s)." << endl;
    }
}

// Calculate mode of movies watched
void calcMode(int toBeMode[], int modeNum) {
    // Initialize largestSort, modeCombination, and largestModeCombo
    int largestSort = 0;
    int modeCombination = 0;
    int largestModeCombo = 0;

    // Declare modeIndices
    vector<int> modeIndices;

    // Bubble sort toBeMode
    for (int i = 0; i < modeNum; i++) {
        for (int x = 1; x < modeNum; x++) {
            if (toBeMode[x] < toBeMode[x - 1]) {
                largestSort = toBeMode[x - 1];
                toBeMode[x - 1] = toBeMode[x];
                toBeMode[x] = largestSort;
            }
        }
    }

    // Add first index of toBeMode to modeIndices
    modeIndices.push_back(0);

    // Determine most often numbers of toBeMode
    for (int i = 1; i < modeNum; i++) {
        // Count through toBeMode
        if (toBeMode[i] == toBeMode[i - 1]) {
            modeCombination++;
        }
        else {
            modeCombination = 0;
        }

        // Add indices to modeIndices
        if (modeCombination > largestModeCombo) {
            largestModeCombo = modeCombination;
            modeIndices.clear();
            modeIndices.push_back(i);
        }
        else if (modeCombination == largestModeCombo) {
            modeIndices.push_back(i);
        }
    }

    // Display modes
    cout << "The vales most often found of movies watched are ";
    for (int i = 0; i < (modeIndices.size() - 1); i++) {
        cout << toBeMode[modeIndices[i]] << ", ";
    }
    cout << toBeMode[modeIndices[(modeIndices.size()) - 1]] << " movie(s)." << endl;

}