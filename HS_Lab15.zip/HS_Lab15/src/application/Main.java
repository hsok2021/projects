/*
Author: Hunter Sokolis
Date: 12/4/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program will rotate a rectangle 15 degrees when the "Rotate" button is pressed.
 */

package application;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;

public class Main extends Application {
	private RectPane rectPane = new RectPane();
    @Override
    public void start(Stage primaryStage) {
    	HBox hBox = new HBox();
    	hBox.setSpacing(5);
    	hBox.setAlignment(Pos.CENTER);
    	Button btRotate = new Button("Rotate");
    	hBox.getChildren().add(btRotate);
    	
    	btRotate.setOnAction(new RotateHandler());
    	
    	BorderPane borderPane = new BorderPane();
    	borderPane.setCenter(rectPane);
    	borderPane.setBottom(hBox);
    	BorderPane.setAlignment(hBox, Pos.CENTER);
    	
    	Scene scene = new Scene(borderPane, 200, 250);
    	primaryStage.setTitle("RotateRectangle");
    	primaryStage.setScene(scene);
    	primaryStage.show();
    }
    
    class RotateHandler implements EventHandler<ActionEvent> {
    	@Override
    	public void handle(ActionEvent e) {
    		rectPane.getTransforms().add(new Rotate(15, 100, 112.5));
    	}
    }
    
    class RectPane extends StackPane {
    	private Rectangle rect = new Rectangle(50, 100);
    	
    	public RectPane() {
    		getChildren().add(rect);
    		rect.setStroke(Color.BLACK);
    		rect.setFill(Color.WHITE);
    	}
    }

    public static void main(String[] args) {
        launch(args);
    }
}