#include <fstream>
#include <map>
#include <iostream>

int main() {

	std::map<std::string, int> wordCount{
		std::pair<std::string, int>("a", 1),
		std::pair<std::string, int>("big", 1),
		std::pair<std::string, int>("cat", 2),
		std::pair<std::string, int>("does", 3),
		std::pair<std::string, int>("everything", 5),
		std::pair<std::string, int>("feeding", 8),
		std::pair<std::string, int>("goats", 13),
		std::pair<std::string, int>("helping", 21),
		std::pair<std::string, int>("injured", 34),
		std::pair<std::string, int>("juvenile", 55),
		std::pair<std::string, int>("kangaroos", 89),
		std::pair<std::string, int>("locating", 144),
		std::pair<std::string, int>("missing", 233),
		std::pair<std::string, int>("notorious", 377),
		std::pair<std::string, int>("objects", 610),
		std::pair<std::string, int>("playing", 987),
		std::pair<std::string, int>("quietly", 1597),
		std::pair<std::string, int>("reading", 2584),
		std::pair<std::string, int>("superb", 4181),
		std::pair<std::string, int>("tales", 6765),
		std::pair<std::string, int>("upvoting", 10946),
		std::pair<std::string, int>("videos", 17711),
		std::pair<std::string, int>("with", 28657),
		std::pair<std::string, int>("xylophone", 46368),
		std::pair<std::string, int>("yielding", 75025),
		std::pair<std::string, int>("zebras", 121393),
	};

	// commented to work without text file submission
	/*
	std::ifstream input("text.txt");
	if (input.fail() == true) {
		std::cout << "failed to open file" << std::endl;
	}
	else {
		while (input.eof() == false) {
			std::string word;
			input >> word;

			if (wordCount.find(word) == wordCount.end()) {
				wordCount.insert(std::pair<std::string, int>(word, 1));
			}
			else {
				wordCount.find(word)->second++;
			}
		}
	}
	input.close();
	*/

	std::map<std::string, int>::iterator iter1 = wordCount.begin();
	while (iter1 != wordCount.end()) {
		std::cout << iter1->first << " ";
		++iter1;
	}
	std::cout << std::endl;

	// Fibonacci
	std::map<std::string, int>::iterator iter2 = wordCount.begin();
	while (iter2 != wordCount.end()) {
		std::cout << iter2->first << " " << iter2->second << std::endl;
		++iter2;
	}

	return 0;
}