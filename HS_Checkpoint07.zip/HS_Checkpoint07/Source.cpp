#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <set>

// --------------------------------------------------------
// 2567 elements hardcoded into this vector before you here
// --------------------------------------------------------
const std::vector<std::string> words {
	"headline","bury","work","satisfy","congressional","photograph","museum","ensure","politically","embrace",
	"ready","oven","criminal","win","mark","then","quit","lawyer","assess","account",
	"recruit","record","massive","hear","bus","wander","primary","seek","science","around",
	"attend","draw","expansion","anywhere","surgery","ship","understand","insurance","observe","wait",
	"book","wave","intelligence","interpret","location","will","pan","pole","supposed","low",
	"rock","achievement","fan","male","popular","permanent","nor","milk","mouth","department",
	"estate","subsequent","tradition","abroad","terrible","retain","inform","reaction","war","modest",
	"concept","mountain","historic","canadian","planning","assure","ceiling","thin","helpful","impossible",
	"potentially","repeatedly","everyday","million","spiritual","bed","half","competitor","suspect","boyfriend",
	"instrument","conflict","galaxy","pace","slight","more","strange","settlement","health","promise",
	"owe","newspaper","widely","pursue","arrangement","stretch","face","encounter","basket","sell",
	"mystery","classroom","quarter","marketing","jury","burden","error","possess","operating","criticize",
	"transportation","message","tension","transform","relationship","confirm","practice","terror","wise","yesterday",
	"painter","golden","lawsuit","per","capable","agreement","homeless","water","fifteen","fall",
	"security","call","quickly","yeah","pale","car","largely","production","faculty","into",
	"increasingly","cold","appeal","for","access","musician","farmer","animal","vote","construct",
	"revolution","particular","convention","city","back","push","original","self","contest","library",
	"pressure","tournament","by","appointment","lesson","structure","activist","composition","fate","employee",
	"mental","previously","cup","angle","environment","mention","hang","end","arrival","forest",
	"agenda","incorporate","couple","law","terrorist","appoint","baby","problem","corporate","garden",
	"meaning","transition","offense","segment","prescription","mind","calculate","pair","beyond","fly",
	"seed","easy","bag","pay","clearly","form","expose","here","rush","medium",
	"regarding","sign","theory","musical","news","horror","rely","shelter","mortgage","central",
	"hurt","remaining","opening","english","lift","middle","highlight","nod","insist","essential",
	"day","affect","slightly","handle","worry","collapse","responsibility","decide","her","wipe",
	"whom","seriously","meanwhile","blow","hole","father","dramatic","recognize","together","decline",
	"danger","distance","device","official","portray","injury","knee","supply","framework","action",
	"be","area","positive","time","arrest","desire","education","administrator","pile","elderly",
	"heat","attractive","sand","instance","twin","risk","column","resist","mutual","farm",
	"park","psychologist","special","extraordinary","desk","existing","course","healthy","he","observation",
	"sequence","article","butter","exposure","okay","potato","page","volume","submit","born",
	"manner","practical","constantly","hospital","identify","apparent","already","poverty","asset","convert",
	"rise","late","preparation","loss","component","glad","successfully","electric","barrier","themselves",
	"distribution","priority","collective","continue","deliver","commercial","penalty","general","capability","distribute",
	"gay","satisfaction","budget","killing","treaty","military","perfectly","rarely","introduction","everyone",
	"introduce","prayer","two","up","lover","find","wine","fourth","artist","soul",
	"fuel","tunnel","long-term","adjust","differently","lean","important","perceive","impose","campaign",
	"ceo","british","wash","illustrate","celebrity","machine","acid","hand","resident","necessary",
	"early","protest","length","side","beast","mean","potential","birthday","furniture","recover",
	"company","onto","crew","legislation","than","necessarily","infection","pull","pretty","speech",
	"viewer","good","candidate","prosecutor","existence","percentage","reduction","participant","building","opposite",
	"program","over","tube","gently","thanks","silent","street","lady","episode","lead",
	"lung","entry","left","symptom","rapidly","probably","depression","shopping","hearing","magazine",
	"publish","expert","attack","limitation","accident","transformation","attribute","stress","occupy","testing",
	"real","consider","learning","against","cost","occupation","service","regional","remove","purchase",
	"particularly","loud","wish","save","search","reality","alter","native","explanation","meet",
	"pretend","provide","constant","church","murder","maintain","boss","suddenly","asleep","student",
	"assert","capacity","developing","legacy","answer","unknown","advantage","like","pink","forget",
	"exactly","ongoing","select","progress","e-mail","rope","mirror","pregnant","examination","soon",
	"cognitive","closer","fabric","writer","method","land","visual","apple","shower","get",
	"violation","innocent","airport","nonetheless","online","wear","publication","defense","cultural","reservation",
	"discuss","senator","shortly","fire","majority","boy","egg","social","translate","transfer",
	"beat","customer","obvious","agent","tap","boat","cholesterol","amount","advice","hire",
	"idea","primarily","cry","target","assume","girlfriend","acquire","committee","facility","wealth",
	"armed","word","emerge","mass","economist","individual","weigh","some","associate","home",
	"beauty","participate","similar","opportunity","continued","examine","goal","not","scholarship","neither",
	"bake","assessment","habitat","aid","tissue","history","across","category","evening","designer",
	"busy","gifted","container","drag","comfort","gallery","salary","flower","resolve","reason",
	"extend","so","sensitive","perception","motivation","of","violent","aggressive","job","iron",
	"imagine","life","offensive","chocolate","safe","partly","sick","entire","severe","different",
	"belt","aware","completely","twelve","southern","organic","stability","ski","philosophy","acknowledge",
	"engineering","path","common","famous","plenty","gather","capital","volunteer","combination","feel",
	"deficit","dear","resort","technology","load","argument","bet","myself","barrel","cheese",
	"bullet","absorb","leading","airline","menu","glance","permit","custom","correspondent","assist",
	"explore","system","remember","supporter","laboratory","scheme","setting","allow","preference","improvement",
	"representation","admission","adventure","measure","borrow","neck","lip","mine","user","sir",
	"terrorism","gift","biological","bear","zone","including","selection","literature","behind","retire",
	"license","weak","aim","daily","approach","process","electronic","diet","valuable","equipment",
	"concrete","medication","campus","commitment","charge","turn","circle","commission","seem","mayor",
	"implement","listen","bean","youth","reputation","battery","reader","newly","grocery","leather",
	"cat","holiday","beneath","stop","heaven","secretary","officer","heritage","confident","award",
	"unable","increasing","exceed","tea","scientist","undergo","nevertheless","available","can","teacher",
	"margin","team","benefit","survive","holy","evaluate","sea","debt","contrast","indicate",
	"yes","recommendation","line","worth","preserve","discussion","director","essentially","college","relative",
	"operate","creature","competitive","saving","district","function","me","yellow","want","controversial",
	"extent","private","minister","pine","direction","ingredient","complicated","far","bridge","additional",
	"impressive","elementary","compose","fellow","garage","perform","concentration","enforcement","educational","assistance",
	"breathe","folk","ethics","carrier","rather","income","somewhere","counter","from","however",
	"come","privacy","evolution","besides","main","contribute","true","effort","fit","depending",
	"detail","brilliant","double","alcohol","else","less","generation","this","tough","adviser",
	"current","interest","employ","position","fashion","represent","natural","during","empty","bright",
	"bite","enable","discover","army","beginning","garlic","conclusion","comedy","whatever","corner",
	"notice","dangerous","soup","investor","distinct","yell","obviously","lucky","angry","member",
	"eager","athletic","warm","pack","construction","generally","give","sustain","weapon","domestic",
	"key","leadership","avoid","pipe","hungry","traditional","fact","little","balance","demand",
	"culture","cookie","spirit","origin","age","negotiation","ignore","install","creative","road",
	"interview","narrative","inquiry","wife","absolute","client","growth","yet","soft","gradually",
	"mad","map","champion","ride","unusual","advertising","suggest","leg","same","strategic",
	"teenager","them","purpose","survivor","hold","missile","defend","reference","silver","release",
	"schedule","plot","corn","vulnerable","latter","live","interaction","reading","annual","personal",
	"next","powerful","lot","tall","compete","data","chicken","basketball","perhaps","uniform",
	"writing","visible","intervention","unfortunately","protection","emission","professional","ability","funding","snap",
	"wing","celebrate","artistic","able","relatively","explode","specifically","information","increased","town",
	"overall","bar","toe","earn","beside","hard","bomb","elsewhere","entrance","apart",
	"that","nation","wall","perspective","people","joy","welfare","thousand","absence","radical",
	"justify","downtown","market","mother","step","full","scandal","hit","pop","within",
	"global","act","psychology","electricity","recommend","psychological","tell","rate","fairly","memory",
	"view","variable","normal","upon","tool","religious","according","dramatically","foundation","way",
	"peer","shut","background","interpretation","flavor","attempt","prominent","changing","wisdom","resemble",
	"root","tobacco","expect","recent","widespread","curious","money","simple","temporary","star",
	"pattern","hero","adopt","who","otherwise","change","consume","sit","factory","independent",
	"office","jail","establishment","plastic","very","host","picture","consistent","ugly","sing",
	"discourse","heel","desperate","boot","region","emotion","therefore","computer","legitimate","creation",
	"intend","emotional","software","any","headquarters","controversy","dry","discrimination","foreign","ad",
	"accomplish","death","agricultural","request","capture","fundamental","following","educator","dead","consensus",
	"switch","confront","stomach","agree","previous","with","league","universe","public","mess",
	"convince","rose","arm","expensive","furthermore","tonight","mode","eventually","protein","difficult",
	"efficient","objective","character","hip","flight","clothing","support","admire","passenger","decision",
	"bowl","educate","wood","stable","size","trouble","meal","experience","ceremony","touch",
	"note","wet","its","obligation","intensity","lovely","do","cancer","cool","kind",
	"spring","immediate","dismiss","branch","technique","procedure","open","guy","rain","enough",
	"profile","rice","friendly","effectively","chemical","drawing","vs","aircraft","fear","except",
	"citizen","childhood","manufacturer","partnership","athlete","evaluation","last","winter","hate","deck",
	"take","date","adapt","frequently","ill","best","improve","create","because","numerous",
	"imagination","medicine","require","bird","entirely","especially","growing","nobody","emergency","investment",
	"achieve","proceed","partner","poem","abuse","if","task","economic","whether","patient",
	"hide","assault","physician","accept","research","show","worried","button","truly","careful",
	"replace","fishing","bike","labor","condition","sigh","sun","impact","disagree","spokesman",
	"extremely","active","also","highway","five","restaurant","critical","producer","female","poor",
	"either","interesting","towards","actual","unit","trip","venture","link","through","cow",
	"box","characterize","environmental","dirty","inflation","proposal","dispute","cluster","pocket","down",
	"eat","flat","likely","ok","teaching","advocate","recording","odds","telephone","highly",
	"game","look","material","poetry","fighting","standard","screen","argue","nice","regulate",
	"solution","funeral","cousin","incredible","comprehensive","edition","brother","negative","control","peak",
	"wonderful","slow","ticket","barely","lie","cooking","ultimately","instruction","concentrate","kiss",
	"invite","portrait","relation","go","international","fast","efficiency","declare","hot","married",
	"code","talk","impress","breath","mood","chairman","ago","ice","instead","subject",
	"him","return","minority","characteristic","fitness","nuclear","vary","storage","guarantee","everybody",
	"celebration","hour","just","refugee","shoe","flag","grab","sudden","roughly","lap",
	"conference","editor","unless","institution","battle","discovery","naturally","bedroom","adolescent","project",
	"sure","finish","tremendous","one","mainly","era","tactic","actress","pray","instructor",
	"seat","liberal","demonstrate","awareness","dish","safety","raw","say","predict","moon",
	"resource","attorney","item","application","dealer","academic","monitor","advanced","prospect","boom",
	"when","identity","external","red","type","wedding","adjustment","illegal","manager","mostly",
	"long","eliminate","odd","studio","billion","although","refuse","quality","content","training",
	"landscape","high","throughout","involvement","daughter","husband","gender","remote","respondent","illness",
	"governor","tank","gun","occasion","loan","element","wake","west","christmas","intense",
	"thus","amazing","professor","ten","settle","racial","involved","our","album","advise",
	"digital","conservative","reject","myth","failure","independence","reduce","totally","hit","restriction",
	"what","lawn","anybody","shoulder","bad","tree","captain","regardless","know","factor",
	"clinical","but","prisoner","finger","swim","straight","school","rule","moreover","appropriate",
	"fill","cell","really","heavily","clothes","lifetime","mere","chance","success","politician",
	"variation","row","anniversary","status","successful","winner","hey","entertainment","permission","hi",
	"finance","another","tourist","hair","restore","never","crop","parent","grow","air",
	"crucial","assistant","receive","addition","speaker","neighborhood","soldier","four","hill","reflection",
	"king","attract","precisely","nature","criticism","somewhat","doctor","destroy","mask","county",
	"mix","collection","alive","therapy","possibly","conviction","secure","wild","democracy","consumption",
	"surely","personality","post","somehow","us","approval","song","involve","month","priest",
	"dad","recipe","signal","explosion","damage","realize","weather","contain","deserve","band",
	"throat","help","in","comment","employer","ethnic","nothing","diversity","again","surface",
	"communicate","running","cop","follow","counselor","old","their","easily","leader","organize",
	"stay","executive","originally","weekend","product","design","platform","shot","shadow","near",
	"year","interested","engineer","consumer","forever","whisper","square","physical","infant","rating",
	"alliance","body","ban","wealthy","joke","vacation","player","yard","height","talent",
	"club","promote","anyway","spot","regard","species","set","carbon","weight","stupid",
	"reform","finding","personally","present","extensive","afraid","contract","anticipate","friendship","stranger",
	"powder","remind","flow","card","statement","dominate","apartment","decade","make","remarkable",
	"cap","agency","chef","tie","launch","handful","development","cope","watch","virtue",
	"leaf","violence","publicly","silence","art","dimension","apparently","romantic","used","hall",
	"ourselves","plan","direct","degree","develop","case","happen","laugh","squeeze","now",
	"disease","rhythm","substance","guilty","hardly","favorite","wide","poll","muscle","lose",
	"slowly","option","review","affair","arise","nowhere","authority","performance","copy","audience",
	"strike","extreme","golf","founder","painting","bottle","consideration","essay","n't","engine",
	"passage","tendency","respond","demonstration","scream","university","teen","arrange","incentive","marriage",
	"suppose","admit","testimony","coalition","consist","strongly","community","mail","experiment","rough",
	"apply","pepper","traffic","invest","mall","opponent","etc","must","fund","fade",
	"bell","attention","add","bathroom","yourself","freedom","conduct","significant","lab","presidential",
	"define","household","certain","association","analysis","between","name","expression","advance","lock",
	"sometimes","cite","federal","routine","tax","twenty","criteria","workshop","about","differ",
	"whereas","behavior","climate","complain","business","courage","feature","number","sky","tooth",
	"ally","variety","complete","immigration","mom","everywhere","phenomenon","movement","television","wage",
	"manufacturing","love","disappear","disorder","prepare","approximately","influence","implication","display","oil",
	"population","six","mixture","object","rank","foot","carefully","via","insight","regime",
	"publisher","port","commander","standing","accompany","consultant","personnel","much","somebody","challenge",
	"organization","substantial","rid","determine","toss","steady","gray","layer","pant","master",
	"tend","document","relief","deputy","always","certainly","conversation","tape","suit","version",
	"we","delivery","hope","measurement","eye","country","past","beautiful","camp","formation",
	"representative","nervous","river","defendant","register","notion","overcome","inside","pregnancy","unlikely",
	"atmosphere","tour","circumstance","relate","deny","math","choice","buy","pour","something",
	"palm","appear","race","recovery","wonder","definitely","deal","sentence","such","as",
	"drop","survey","after","comparison","victim","session","matter","chapter","pet","discipline",
	"package","narrow","fine","above","guideline","strategy","sufficient","depth","theater","secret",
	"tomorrow","sue","sad","western","appearance","phrase","move","wire","requirement","basically",
	"desert","week","drug","pure","soccer","period","violate","gate","huge","meat",
	"dialogue","religion","out","tongue","village","snow","impression","testify","dinner","plus",
	"modern","expand","thinking","breakfast","payment","participation","please","bend","dust","season",
	"historian","tennis","qualify","quarterback","read","victory","nomination","today","enormous","pain",
	"gaze","invasion","tail","consciousness","edge","fantasy","channel","script","democratic","historical",
	"council","bone","nine","threaten","fish","debate","specialist","distant","description","dependent",
	"report","reach","die","satellite","constitutional","moment","reporter","passion","should","outside",
	"most","formula","miss","surprisingly","literary","accurate","compare","difference","difficulty","situation",
	"ground","motion","complaint","lost","cotton","properly","defeat","complex","coverage","hunting",
	"shop","makeup","medical","ear","ultimate","engage","vision","comfortable","pie","feeling",
	"put","soil","warning","universal","political","portion","become","protect","journalist","ancient",
	"attach","tire","and","net","station","actually","finally","derive","assign","site",
	"threat","bombing","charity","result","curriculum","match","remain","average","salt","care",
	"surprised","freeze","exchange","economy","anyone","virtually","briefly","bottom","propose","test",
	"surprise","door","even","career","spread","surround","killer","significantly","operator","meeting",
	"singer","politics","bond","resistance","wrap","sanction","definition","cook","roll","cash",
	"belief","sale","to","analyze","currently","reflect","hell","suffer","relevant","lifestyle",
	"boundary","formal","no","vast","persuade","stir","your","devote","part","appreciate",
	"dig","let","address","identification","detect","constitute","choose","orientation","warn","regular",
	"tone","broken","announce","source","colleague","dare","blanket","island","strengthen","spending",
	"try","morning","role","burn","oh","scared","firm","man","rub","walk",
	"unlike","reasonable","marry","sophisticated","slip","coat","technical","expectation","reply","dirt",
	"strength","profit","pollution","significance","colonial","chamber","contemporary","kick","provision","assignment",
	"she","senior","luck","tale","run","perfect","ball","kid","corporation","vessel",
	"opposition","ask","confusion","gesture","detailed","stroke","grandmother","industrial","negotiate","you",
	"motor","skin","whenever","on","ah","chip","intention","ring","national","serious",
	"activity","expense","anger","oppose","bother","decrease","earth","frequency","teaspoon","ordinary",
	"province","herself","tragedy","commit","absolutely","string","lunch","investigation","son","evolve",
	"familiar","proportion","have","section","everything","occasionally","prevent","grandfather","awful","manage",
	"greatest","policy","none","collect","connection","later","working","justice","recently","refer",
	"beer","obtain","big","dominant","operation","major","feed","football","estimate","fat",
	"disaster","gang","increase","east","assumption","survival","well","exercise","cut","suicide",
	"hex","enhance","mm-hmm","lake","future","vegetable","fix","accuse","fun","century",
	"many","extension","pool","second","former","believe","united","living","letter","jacket",
	"fiction","despite","effect","itself","include","sacred","withdraw","sake","rich","tent",
	"wooden","journal","maintenance","financial","resolution","nearby","produce","parking","tower","administration",
	"simply","contribution","connect","typical","sink","usually","bind","observer","away","distinguish",
	"maker","escape","inspire","exception","similarly","gear","rare","at","dark","employment",
	"critic","architect","exciting","eastern","mechanism","better","file","without","free","anymore",
	"driver","telescope","response","distinction","aside","person","treatment","bit","honest","jump",
	"single","kill","new","fee","intellectual","credit","ease","gold","election","fighter",
	"recall","arrive","film","author","president","statistics","conventional","destruction","see","mistake",
	"bill","send","play","truth","shooting","god","versus","communication","few","tip",
	"sin","neighbor","example","aspect","kitchen","summit","enter","weekly","institutional","punishment",
	"abandon","describe","before","so-called","useful","gentleman","internet","question","pose","himself",
	"immigrant","hundred","divide","own","stream","diverse","cake","tiny","text","clinic",
	"cigarette","directly","only","witness","enterprise","exhibit","deeply","defensive","scientific","legend",
	"specific","depict","immediately","principle","emphasize","territory","presentation","merely","approve","anxiety",
	"toward","prefer","lay","hypothesis","nearly","depend","concert","visitor","camera","principal",
	"off","exhibition","analyst","flee","possibility","establish","sample","provider","disability","excellent",
	"junior","graduate","repeat","context","fortune","aide","opinion","border","vehicle","which",
	"sort","civilian","struggle","top","confidence","scenario","presence","understanding","miracle","afternoon",
	"incident","deer","head","suggestion","responsible","both","cast","darkness","taxpayer","explain",
	"express","consequence","roof","reinforce","membership","scholar","gain","multiple","conclude","anything",
	"worker","possible","abortion","effective","dining","symbol","series","indeed","someone","adequate",
	"toy","crisis","several","initial","too","all","attitude","ever","emphasis","various",
	"his","journey","ahead","championship","bank","surprising","importance","may","proper","alone",
	"locate","researcher","cooperation","housing","literally","government","police","regulation","pass","classic",
	"valley","investigate","figure","tear","urge","investigator","combine","base","network","helicopter",
	"equally","they","encourage","nut","limited","strong","energy","deep","painful","lack",
	"frequent","alternative","window","photographer","indication","language","clue","blue","spin","wind",
	"sector","actor","welcome","typically","afford","prison","my","keep","quietly","join",
	"girl","teach","belong","thought","northern","retirement","hat","willing","friend","society",
	"cabinet","fair","frustration","lower","hunter","reveal","management","summer","knowledge","pot",
	"rest","competition","closely","minor","coal","rail","evidence","utility","proposed","how",
	"veteran","every","due","coffee","each","why","generate","travel","economics","orange",
	"gas","horizon","thirty","dog","or","initially","duty","pick","normally","smooth",
	"divorce","the","tomato","considerable","poet","nose","food","property","command","moderate",
	"physically","profession","core","correct","forward","industry","unique","baseball","room","family",
	"term","concern","north","mission","tablespoon","pleasure","once","regularly","division","lots",
	"others","prompt","initiative","succeed","need","contact","concerned","use","it","sister",
	"recognition","center","overlook","earnings","minute","judgment","outcome","buck","auto","planet",
	"gene","genetic","fail","respect","separate","almost","revenue","list","gap","internal",
	"enjoy","though","meter","delay","temperature","supreme","jet" };

// PART 2
// Create a boolean function that takes four strings as parameters and determines if it all fits the shape needed for the puzzle
//		Note the first letter of A must be the same as the first letter of D
//		Note the  last letter of A must be the same as the first letter of B
//		Note the  last letter of B must be the same as the  last letter of C
//		Note the  last letter of D must be the same as the first letter of C
//		None of the other letters have to be matched up

bool doWordsFit(std::string A, std::string B, std::string C, std::string D) {
	if (A.at(0) == D.at(0)) {
		if (A.at(4) == B.at(0)) {
			if (B.at(4) == C.at(4)) {
				if (D.at(4) == C.at(0)) {
					return true;
				}
			}
		}
	}
	return false;
}

int main()
{
	// PART 1
	// Iterate through your std::vector of strings above and copy only the words that are five letters long into an std::list of strings
	// There will be 91 elements in the list when complete

	std::list<std::string> fiveLetterWords;

	std::vector<std::string>::const_iterator iter = words.cbegin();
	while (iter != words.cend()) {
		if (iter->length() == 5) {
			fiveLetterWords.push_back(*iter);
		}
		++iter;
	}

	// PART 3
	// Try every combination of the 91 five letter words against each other (91 * 91 * 91 * 91 = 68, 574, 961 possibilities) to see how many of them could be used for puzzle days
	//		A valid combination cannot have the same word used twice
	//		A set is a perfect and easy way to test for this
	//		The first valid combination I get is "A=ready B=youth C=rough D=river"
	//		I get 19,110 valid combinations in total...  Do you get the same number?
	//		In case the test case matters to you, if you do forget the unique word rule, you do end up with 22,325 combinations instead
	//		Print out each valid combination as you find them, and also print out the total once your program completes its processing
	int counter = 0;
	for (std::string A : fiveLetterWords) {
		for (std::string B : fiveLetterWords) {
			for (std::string C : fiveLetterWords) {
				for (std::string D : fiveLetterWords) {
					if (A != B && A != C && A != D && B != C && B != D && C != D) {
						if (doWordsFit(A, B, C, D)) {
							std::cout << A << " " << B << " " << C << " " << D << std::endl;
							++counter;
						}
					}
				}
			}
		}
	}
	std::cout << counter << " different combinations";

	return 0;
}