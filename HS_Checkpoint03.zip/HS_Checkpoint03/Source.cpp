#include <iostream>
#include <vector>
#include <algorithm>

void PrintVector(std::vector<int>);

int main() {
	// 2
	std::vector<int> C;
	PrintVector(C);

	std::vector<int> A{ 2, 7, 3, 8, 12, 11 };
	A.reserve(10);
	PrintVector(A);

	std::vector<int> B(A.begin(), A.end());
	B.push_back(9);
	PrintVector(B);

	C.push_back(5);
	C.push_back(1);
	C.push_back(3);
	C.push_back(6);
	C.push_back(9);
	PrintVector(C);

	A.insert(A.begin(), C.begin(), ++C.begin());
	PrintVector(A);

	std::sort(A.begin(), A.end());
	PrintVector(A);

	// 3
	std::string D = "76   aP4   2   F7   1   xT   823   5S";
	for (int i = 0; i < D.size(); ++i) {
		if (isalpha(D.at(i))) {
			D.replace(i, 1, "O");
		}
		else if (isdigit(D.at(i))) {
			D.replace(i, 1, "-");
		}
	}
	std::cout << D << std::endl;

	std::cout << "MUTATION" << std::endl;

	return 0;
}


// 1
void PrintVector(std::vector<int> toPrint) {
	std::cout << " x ";

	if (toPrint.empty()) {
		std::cout << "EMPTY x ";
	}
	else {
		for (int item : toPrint) {
			std::cout << item << " x ";
		}
	}

	std::cout << std::endl;

}