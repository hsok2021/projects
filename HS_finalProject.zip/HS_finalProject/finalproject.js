"use strict";

/*

Author: Hunter Sokolis
Date: 5/11/2023
Description: Program provides a text box to type in the item you wish to add to the shopping list, and a submit button to add that item to the list. Once you hit the "Add Item" button, the new item will appear on the screen.

*/

// Initialization
// Form controls, chapter 6
let inputArea = document.getElementById("input");
let outputArea = document.getElementById("output");
let submitButton = document.getElementById("submit");
// Arrays, chapter 3
let items = ["Hotdogs"];

// Submit button onclick
submitButton.onclick = function() {
   let itemsDisplay = "";

   // Add item to items array
   items.push(inputArea.value);

   // Test if string will display as empty
   if (items[items.length - 1] == "") {
      items[items.length - 1] = "Air";
   }
   else if (items[items.length - 1].charAt(0) == " ") {
      items[items.length - 1] = "Air";
   }

   // Create display text
   for (let i = 0; i < items.length; i++) {
      // Chapter 7, manipulating strings
      itemsDisplay = itemsDisplay.concat(items[i], "<br />");
   }
   outputArea.innerHTML = itemsDisplay;
}