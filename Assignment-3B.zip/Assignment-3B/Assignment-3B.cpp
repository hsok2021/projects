/*
Application Name: Triple Math Calculator
Assignment Number: Unit 3 Assignment 2
Version: 1.0
Description: Program will prompt user for three integers. Program will then determine sum, average, product, greatest number, and least number. Program will
then display output.
Input: Integer
Output: Integer

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/10/2022
*/

#include <iostream>
using namespace std;

int main()
{
    // Data storage
    int integer1, integer2, integer3, sum, average, product, greatest, least;

    // User prompt
    cout << "Please enter three integers separated by spaces." << endl;
    cin >> integer1 >> integer2 >> integer3;

    // Calculation
    sum = integer1 + integer2 + integer3;
    average = sum / 3;
    product = integer1 * integer2 * integer3;

    // Logic
    // Can also be done using boolean operations as well as certain equations
    if (integer1 > integer2) {
        greatest = integer1;
    }
    else if (integer2 > integer3) {
        greatest = integer2;
    }
    else {
        greatest = integer3;
    }

    if (integer1 < integer2) {
        least = integer1;
    }
    else if (integer2 < integer3) {
        least = integer2;
    }
    else {
        least = integer3;
    }

    // Calculation output
    cout << "Sum: " << sum << endl
        << "Average: " << average << endl
        << "Product: " << product << endl
        << "Greatest: " << greatest << endl
        << "Least: " << least << endl;
    return 0;
}
