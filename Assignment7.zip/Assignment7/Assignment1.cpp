/*
Application Name: Employee Database
Assignment Number: Unit 7 Assignment 1
Version: 1.0
Description: The employee database will print a menu that lists the user's ability to display an employee report, search for employees, sort the employee
             report, calculate an employee's pay, and exit the program.
Input: String, integer
Output: String, integer

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 10/5/2022
*/

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

// Global array size

const int EMPLOYEES = 5;

// Global employee arrays (parallel)

string listEmpFirst[EMPLOYEES] = { "Brian", "David", "Kathy", "Janet", "Steve" },
       listEmpLast[EMPLOYEES] = { "Adams", "Eisenhower", "Jones", "Williams", "Bradford" };
int listEmpId[EMPLOYEES] = { 612366, 957654, 123456, 245695, 245690 },
    listEmpHours[EMPLOYEES] = { 36, 38, 43, 39, 39 },
    listEmpPay[EMPLOYEES] = { 15, 20, 15, 30, 20 };

// Function prototyping

// Menu
void displayMenu();

// Employees
void listEmployee(int);
void employeeDisplayReport();
void employeeSearch();
void employeeReportSort();
void employeeCalculatePay();

// Main

int main()
{

    // Data storage

    int menuInput = 1;

    // Display menu and prompt user

    cout << "Welcome to the employee database. Please select a menu option." << endl << endl;
    displayMenu();
    cin >> menuInput;
    cout << endl;

    // Loop menu

    while (menuInput > 0 || menuInput < 5) {
        switch (menuInput) {

            // Print employee report

            case 1:
                employeeDisplayReport();
                break;

            // Employee search

            case 2:
                employeeSearch();
                break;

            // Sort report

            case 3:
                employeeReportSort();
                break;

            // Calculate pay

            case 4:
                employeeCalculatePay();
                break;

            // Quit

            default:
                return 0;
        }

        // Re-display menu and re-prompt

        displayMenu();
        cin >> menuInput;
        cout << endl;

    }
}

// Functions

// Display menu

void displayMenu() {
    cout << "Menu" << endl
        << "-------" << endl
        << "1 - Print out employee report" << endl
        << "2 - Search for an employee" << endl
        << "3 - Sort report" << endl
        << "4 - Calculate pay" << endl
        << "Any number - Quit" << endl;
}

// List employee information in special format

void listEmployee(int index) {
    cout << left;
    cout << setw(11) << listEmpFirst[index] << setw(11) << listEmpLast[index] << setw(11) << listEmpId[index] << setw(11) << listEmpHours[index] << setw(11) << listEmpPay[index] << endl;
}

// Calculate employee pay

void employeeCalculatePay() {

    int choice = 0, totalPay = 0;

    cout << "Who would you like to calculate pay for? (Enter number that employee appears on the report)" << endl;
    cin >> choice;
    choice -= 1;
    cout << endl;

    if (choice > -1 && choice < 5) {
        totalPay = listEmpHours[choice] * listEmpPay[choice];
        
        cout << "The total pay for " << listEmpFirst[choice] << " is $" << totalPay << ".00." << endl << endl;
    }
    else {
        cout << "That is not a valid employee." << endl << endl;
    }

}

// Display employee report

void employeeDisplayReport() {

    int average = 0;

    cout << left;
    cout << setw(11) << "First Name" << setw(11) << "Last Name" << setw(11) << "ID" << setw(11) << "Hours" << setw(11) << "Pay rate" << endl;
    for (int i = 0; i < EMPLOYEES; i++) {
        listEmployee(i);
    }

    for (int i = 0; i < EMPLOYEES; i++) {
        average += listEmpHours[i];
    }
    average /= EMPLOYEES;

    cout << endl << "Average hours worked: " << average << " hours a week.";

    cout << endl << endl;
}

// Sort employee report

void employeeReportSort() {

    string first, last;
    int id = 0, hours = 0, pay = 0, sort = 0;

    cout << "How do you want to sort the report?" << endl
         << "1 - Last name" << endl
         << "Any number - ID" << endl;
    cin >> sort;
    cout << endl;

    // Sort w/ last name

    if (sort == 1) {
        for (int i = 0; i < EMPLOYEES; i++) {
            for (int inI = 1; inI < EMPLOYEES; inI++) {
                if (listEmpLast[inI] < listEmpLast[inI - 1]) {
                    first = listEmpFirst[inI];
                    last = listEmpLast[inI];
                    id = listEmpId[inI];
                    hours = listEmpHours[inI];
                    pay = listEmpPay[inI];

                    listEmpFirst[inI] = listEmpFirst[inI - 1];
                    listEmpLast[inI] = listEmpLast[inI - 1];
                    listEmpId[inI] = listEmpId[inI - 1];
                    listEmpHours[inI] = listEmpHours[inI - 1];
                    listEmpPay[inI] = listEmpPay[inI - 1];

                    listEmpFirst[inI - 1] = first;
                    listEmpLast[inI - 1] = last;
                    listEmpId[inI - 1] = id;
                    listEmpHours[inI - 1] = hours;
                    listEmpPay[inI - 1] = pay;
                }
            }
        }

        for (int i = 0; i < EMPLOYEES; i++) {
            listEmployee(i);
        }
        cout << endl;
    }

    // Sort w/ ID

    else {
        for (int i = 0; i < EMPLOYEES; i++) {
            for (int inI = 1; inI < EMPLOYEES; inI++) {
                if (listEmpId[inI] < listEmpId[inI - 1]) {
                    first = listEmpFirst[inI];
                    last = listEmpLast[inI];
                    id = listEmpId[inI];
                    hours = listEmpHours[inI];
                    pay = listEmpPay[inI];

                    listEmpFirst[inI] = listEmpFirst[inI - 1];
                    listEmpLast[inI] = listEmpLast[inI - 1];
                    listEmpId[inI] = listEmpId[inI - 1];
                    listEmpHours[inI] = listEmpHours[inI - 1];
                    listEmpPay[inI] = listEmpPay[inI - 1];

                    listEmpFirst[inI - 1] = first;
                    listEmpLast[inI - 1] = last;
                    listEmpId[inI - 1] = id;
                    listEmpHours[inI - 1] = hours;
                    listEmpPay[inI - 1] = pay;
                }
            }
        }

        for (int i = 0; i < EMPLOYEES; i++) {
            listEmployee(i);
        }
        cout << endl;
    }

}

// Search for employees

void employeeSearch() {

    string first, last;
    int id = 1, hours = 1, pay = 1, searchChoice = 1, found = 0;

    cout << "Which category do you wish to search for employees by?" << endl
        << "1 - First name" << endl
        << "2 - Last name" << endl
        << "3 - Employee ID" << endl
        << "4 - Hours worked" << endl
        << "Any number - Pay rate" << endl;
    cin >> searchChoice;
    cout << endl;

    switch (searchChoice) {

        // Search w/ first name

        case 1:
            cout << "Please enter the employee's first name." << endl;
            cin >> first;
            cout << endl;

            for (int i = 0; i < EMPLOYEES; i++) {
                if (first == listEmpFirst[i]) {
                    listEmployee(i);
                    found++;
                }
            }
            cout << endl;
            break;

        // Search w/ last name

        case 2:
            cout << "Please enter the employee's last name." << endl;
            cin >> last;
            cout << endl;

            for (int i = 0; i < EMPLOYEES; i++) {
                if (last == listEmpLast[i]) {
                    listEmployee(i);
                    found++;
                }
            }
            cout << endl;
            break;

        // Search w/ ID

        case 3:
            cout << "Please enter the employee's ID number." << endl;
            cin >> id;
            cout << endl;

            for (int i = 0; i < EMPLOYEES; i++) {
                if (id == listEmpId[i]) {
                    listEmployee(i);
                    found++;
                }
            }
            cout << endl;
            break;

        // Search w/ employee hours

        case 4:
            cout << "Please enter the hours the employee has worked." << endl;
            cin >> hours;
            cout << endl;
            
            for (int i = 0; i < EMPLOYEES; i++) {
                if (hours == listEmpHours[i]) {
                    listEmployee(i);
                    found++;
                }
            }
            cout << endl;
            break;

        // Search w/ pay rate

        default:
            cout << "Please enter the pay rate of the employee." << endl;
            cin >> pay;
            cout << endl;

            for (int i = 0; i < EMPLOYEES; i++) {
                if (pay == listEmpPay[i]) {
                    listEmployee(i);
                    found++;
                }
            }
            cout << endl;
            break;

    }

    if (found == 0) {
        cout << "No employees were found." << endl << endl;
    }

}