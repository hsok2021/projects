/*
Application Name: Warehouse Inventory Database
Assignment Number: Unit 11 Assignment 1
Version: 1.0
Description: Displays the contents of 10 bins of parts and asks the user whether or not they wish to add or remove parts from those bins. Repeats
             until the user quits the program.
Input: Integer
Output: String

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 11/3/2022
*/

#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
using namespace std;

struct invBin {
	string partDesc;
	int partNum;
};

void AddParts(invBin[], int);
void RemoveParts(invBin[], int);

int main()
{

	// Initialize userChoice, SIZE, banList, userPart, and userNum
	char userChoice = NULL;
	int userPart = NULL;
	int userNum = NULL;
	const int SIZE = 10;
	invBin binList[10] = { {"Valve", 10},
						   {"Bearing", 5},
						   {"Bushing", 15},
						   {"Coupling", 21},
						   {"Flange", 7},
						   {"Gear", 5},
						   {"Gear Housing", 5},
						   {"Vacuum Gripper", 25},
						   {"Cable", 18},
						   {"Rod", 12} };

	// Display welcome message
	cout << "Welcome to the Warehouse Inventory Database system." << endl << endl;

	while (toupper(userChoice) != 'Q') {

		// Display inventory
		cout << "Current inventory:" << endl << "-----" << endl;
		for (int i = 0; i < SIZE; i++) {
			cout << left;
			cout << setw(17) << binList[i].partDesc << binList[i].partNum << endl;
		}

		// User prompt
		cout << endl << "Would you like to:" << endl << "A - Add parts from item" << endl << "R - Remove parts from item" << endl << "Q - Quit" 
			 << endl;
		cin >> userChoice;
		cout << endl;

		// If user chose to add
		if (toupper(userChoice) == 'A') {
			AddParts(binList, SIZE);
		}

		// If user chose to remove
		if (toupper(userChoice) == 'R') {
			RemoveParts(binList, SIZE);
		}

	}

}

// Add parts function
void AddParts(invBin inputBin[], int SIZE) {
	int userPart = NULL;
	int userNum = NULL;

	// Ask for part number
	do {
		cout << "Which part do you wish to add to?" << endl;
		cin >> userPart;
		userPart--;
		if (userPart < 0 || userPart > 9) {
			cout << "You entered an incorrect part number. Parts are numbered 1 through 10." << endl;
		}
	} while (userPart < 0 || userPart > 9);

	// Ask for part amount
	do {
		cout << "How many " << inputBin[userPart].partDesc << "s do you wish to add?" << endl;
		cin >> userNum;
		if (userNum < 0 || (inputBin[userPart].partNum + userNum) > 30) {
			cout << "You have entered an invalid number. The number of parts being held in the " << inputBin[userPart].partDesc
				<< "s bin is " << inputBin[userPart].partNum << " parts." << endl;
		}
	} while (userNum < 0 || (inputBin[userPart].partNum + userNum) > 30);
	inputBin[userPart].partNum += userNum;
}

// Remove parts function
void RemoveParts(invBin inputBin[], int SIZE) {
	int userPart = NULL;
	int userNum = NULL;

	// Ask for part number
	do {
		cout << "Which part do you wish to remove from?" << endl;
		cin >> userPart;
		userPart--;
		if (userPart < 0 || userPart > 9) {
			cout << "You entered an incorrect part number. Parts are numbered 1 through 10." << endl;
		}
	} while (userPart < 0 || userPart > 9);

	// Ask for part amount
	do {
		cout << "How many " << inputBin[userPart].partDesc << "s do you wish to remove?" << endl;
		cin >> userNum;
		if (userNum < 0 || (inputBin[userPart].partNum - userNum) < 0) {
			cout << "You have entered an invalid number. The number of parts being held in the " << inputBin[userPart].partDesc
				<< "s bin is " << inputBin[userPart].partNum << " parts." << endl;
		}
	} while (userNum < 0 || (inputBin[userPart].partNum - userNum) < 0);
	inputBin[userPart].partNum -= userNum;
}