/*
Application Name: Student Grading System
Assignment Number: Unit 8 Assignment 1
Version: 1.0
Description: Program will prompt user with the first and last names of students and then grades for the three of their classes. The program will
             then calculate the grade averages for each student and then determine whether or not a majority of them met the grade quota.
Input: String, integer
Output: String, integer

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 10/15/2022
*/

#include <iostream>
#include <string>
using namespace std;

int main()
{

    // Data storage
    const int STUDENTS = 5;
    const int CLASSES = 3;
    int classAverage = 0;
    int classNum = 0;
    int averagesNum = 0;

    // Student information arrays
    int studentGrades[STUDENTS][CLASSES];
    string studentFirstNames[STUDENTS];
    string studentLastNames[STUDENTS];
    int studentGradeAverages[STUDENTS];

    // Greeting
    cout << "Welcome to the student grading system!" << endl << endl;

    // Student name inputs
    for (int i = 0; i < STUDENTS; i++) {
        cout << "Please enter student number " << (i + 1) << "'s first name." << endl;
        cin >> studentFirstNames[i];
        cout << "Now, enter student number " << (i + 1) << "'s last name." << endl;
        cin >> studentLastNames[i];
    }

    // Student grade input
    for (int i = 0; i < STUDENTS; i++) {
        for (int &classGrade : studentGrades[i]) {
            cout << "Please enter student " << studentFirstNames[i] << "'s three grades." << endl << "(Entering letters will yield incorrect results)" << endl;

            // Input validation
            do {
                cin >> classGrade;
                if (classGrade < 0 || classGrade > 100) {
                    cout << "It seems you have entered an incorrect grade. You entered " << classGrade << "." << endl <<
                            "You should try entering a number that is greater than or equal to 0, and is less than or equal to 100." << endl;
                    cin.clear();
                    cin.ignore(100, '\n');
                    classGrade = -1;
                }
            } while (classGrade < 0 || classGrade > 100);
        }
    }

    // Calculate averages for all 5 students
    for (int i = 0; i < STUDENTS; i++) {
        classAverage = 0;
        for (int classGrade : studentGrades[i]) {
            classAverage += classGrade;
        }
        classAverage /= CLASSES;
        studentGradeAverages[i] = classAverage;
    }

    // Calculate the number of students who had a grade average above 70%
    for (int average : studentGradeAverages) {
        if (average > 70) {
            averagesNum++;
        }
    }

    // Display whether or not most students met the grade quota
    if ((static_cast<float>(averagesNum) / STUDENTS) > 0.5) {
        cout << "Because more than 50% of students had a grade average above 70% (" << averagesNum << "), tuition will increase by 10% next semester!" << endl;
    }
    else {
        cout << "The majority of students this semester were unable to reach a grade average above 70%" << endl << "(only " << averagesNum << " students reached more than 70 % average).As a result, tuition will not increase.";
    }

    return 0;

}