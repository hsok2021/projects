/*
Application Name: Airline Reservation System
Assignment Number: Unit 13 Assignment 1
Version: 1.0
Description: Prompt the user to check in their desired seat on Flight 243. Users will not be able to book seats in sections that are already
             filled. Once all seats are filled, the program ends.
Input: Integer
Output: String

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 11/18/2022
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Construct Plane class, public void method CheckIn, private integer fClassSeats, private integer econSeats
class Plane {
    public:
        void CheckIn();
    private:
        int fClassSeats = 0;
        int econSeats = 0;
};

int main()
{
    // Create instance of Plane class lh243
    Plane lh243;

    // User welcome and calling CheckIn()
    cout << "Welcome to the Lufthansa Airline Reservation System." << endl;
    lh243.CheckIn();
}

// The CheckIn() method goes through the check-in routine for the flight until no more seats remain
void Plane::CheckIn() {

    // Loop until no more seats remain
    while (fClassSeats <= 4 || econSeats <= 4) {

        // Initialize seatChoice and firstTime
        int seatChoice = 1;
        int firstTime = 1;

        // User prompt
        cout << "Which type of seat do you wish to check in?" << endl << "1 - First class" << endl << "2 - Economy" << endl;

        // Input validation, seat choice must be valid and available
        do {

            // If seat choice is invalid
            if (seatChoice != 1 && seatChoice != 2) {
                cout << seatChoice << " is not a valid seat option. Please choose between 1 and 2." << endl;
            }

            // If seat choice is full
            if (((seatChoice == 1 && fClassSeats >= 5) || (seatChoice == 2 && econSeats >= 5)) && firstTime != 1) {
                cout << "No more seats are available for your selection. Please choose another seating option." << endl;
            }

            // Increment firstTime to notify program that it is no longer the first runthrough
            firstTime++;

            // User input
            cin >> seatChoice;
        } while ((seatChoice != 1 && seatChoice != 2) || (seatChoice == 1 && fClassSeats >= 5) || (seatChoice == 2 && econSeats >= 5));

        // Switch statement for seatChoice
        switch (seatChoice) {

            // Increment fClassSeats by 1
            case 1:
                cout << endl << "You have selected a first class seat." << endl;
                fClassSeats++;

                // Notify user if they have taken the last seat
                if (fClassSeats >= 5) {
                    cout << "You have taken the last seat in the first class." << endl;
                }
                cout << endl << "-----" << endl;
                break;

            // Increment econSeats by 1
            case 2:
                cout << endl << "You have selected an economy seat." << endl;
                econSeats++;

                // Notify user if they have taken the last seat
                if (econSeats >= 5) {
                    cout << "You have taken the last seat in the economy class." << endl;
                }
                cout << endl << "-----" << endl;
                break;

            // Default statement incase of error
            default:
                cout << "Error" << endl;
                return;
                break;
        }
    }

    // Final check-in message
    cout << "All seats have been filled." << endl << "Thank you for flying with Lufthansa." << endl;
}