/*
Application Name: Bank System
Assignment Number: Final Project Assignment 1
Version: 1.0
Description: Framework for a bank program. Contains one base class, Account, and two derived classes, SavingsAccount and CheckingAccount.
             Account Contains member initialBalance and methods getInitialBalance(), setInitialBalance(double initBal), credit(double amount), and 
             debit(double amount).
             CheckingAccount contains member transactionFee and methods getTransactionFee(), setTransactionFee(double transFee), 
             overridden credit(double amount), and overridden debit(double amount).
             SavingsAccount contains member interestRate and methods getInterestRate(), setInterestRate(double intRate), and calculateInterest().

             credit(double amount) and debit(double amount) allow users to deposit and withdraw money from accounts respectively. These overriden 
             methods in CheckingAccount both subtract transactionFee from the transaction when called.
             calculateInterest() displays the interest owed from SavingsAccount by multiplying initialBalance by interestRate.
             The program tests multiple situations. Uncomment them to test them.

             Situation 1 simply tests the methods of each class.
             Situation 2 creates a polymorphic banking system that has the user withdraw and deposit money from four accounts. The program will 
             then decide whether the account is a checking account or savings account. If the account is a savings account, the program will 
             display the interest owed and then credit the interest to the account and the current balance will be displayed. If the account is a 
             checking account, only the current balance will be displayed.
             Situation 3 allows the user to populate four accounts with information.
Input: Double
Output: Double, String

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 12/11/2022
*/

#include <iostream>
#include <iomanip>
#include "account.h"
#include "savingsaccount.h"
#include "checkingaccount.h"
using namespace std;

int main()
{

    // ---------------------------------------------
    //                 First Test
    // ---------------------------------------------

    /*
    
    // Creating accounts
    Account tAc1 = { 1000.0 };
    SavingsAccount tSAc2 = { 500.0, 0.08 };
    CheckingAccount tCAc3 = { 800.0, 2.50 };

    // Explanation
    cout << "Testing tAc1(test Account object)'s methods." << endl;

    // Testing all of tAc1's methods
    cout << "getInitialBalance(): ";
    cout << tAc1.getInitialBalance() << endl;
    cout << "setInitialBalance(400.0): ";
    tAc1.setInitialBalance(400.0);
    cout << tAc1.getInitialBalance() << endl;
    cout << "credit(10.0): ";
    tAc1.credit(10.0);
    cout << tAc1.getInitialBalance() << endl;
    cout << "credit(-10.0): ";
    tAc1.credit(-10.0);
    cout << tAc1.getInitialBalance() << endl;
    cout << "debit(20.0): ";
    tAc1.debit(20.0);
    cout << tAc1.getInitialBalance() << endl;
    cout << "debit(600.0): ";
    tAc1.debit(600.0);
    cout << tAc1.getInitialBalance() << endl;

    // Explanation
    cout << endl << "Testing tSAc2(test SavingsAccount object)'s methods." << endl;

    // Testing all of tSAc2's methods
    cout << "getInitialBalance(): ";
    cout << tSAc2.getInitialBalance() << endl;
    cout << "getInterestRate(): ";
    cout << tSAc2.getInterestRate() << endl;
    cout << "setInterestRate(0.07): ";
    tSAc2.setInterestRate(0.07);
    cout << tSAc2.getInterestRate() << endl;
    cout << "credit(10.0): ";
    tSAc2.credit(10.0);
    cout << tSAc2.getInitialBalance() << endl;
    cout << "credit(-10.0): ";
    tSAc2.credit(-10.0);
    cout << tSAc2.getInitialBalance() << endl;
    cout << "debit(20.0): ";
    tSAc2.debit(20.0);
    cout << tSAc2.getInitialBalance() << endl;
    cout << "debit(600.0): ";
    tSAc2.debit(600.0);
    cout << tSAc2.getInitialBalance() << endl;

    // Crediting tSAc2 with its interest
    cout << "calculateInterest(): ";
    cout << tSAc2.calculateInterest() << endl;
    cout << "credit(tSAc2.calculateInterest()): ";
    tSAc2.credit(tSAc2.calculateInterest());
    cout << tSAc2.getInitialBalance() << endl;

    // Explanation
    cout << endl << "Testing tCAc3(test CheckingAccount object)'s methods." << endl;

    // Testing all of tSAc2's methods
    cout << "getInitialBalance(): ";
    cout << tCAc3.getInitialBalance() << endl;
    cout << "getTransactionFee(): ";
    cout << tCAc3.getTransactionFee() << endl;
    cout << "setTransactionFee(5.0): ";
    tCAc3.setTransactionFee(5.0);
    cout << tCAc3.getTransactionFee() << endl;
    cout << "credit(10.0): ";
    tCAc3.credit(10.0);
    cout << tCAc3.getInitialBalance() << endl;
    cout << "credit(-10.0): ";
    tCAc3.credit(-10.0);
    cout << tCAc3.getInitialBalance() << endl;
    cout << "debit(20.0): ";
    tCAc3.debit(20.0);
    cout << tCAc3.getInitialBalance() << endl;
    cout << "debit(1000.0): ";
    tCAc3.debit(1000.0);
    cout << tCAc3.getInitialBalance() << endl;
    
    */

    // ---------------------------------------------
    //                 Second Test
    // ---------------------------------------------

    /*
    
    // Creating accounts array
    const int SIZE = 4;
    Account *accounts[SIZE] = { new CheckingAccount{200.0, 2.0},
                                new SavingsAccount{175.0, 0.05},
                                new CheckingAccount{150.0, 1.25},
                                new SavingsAccount{250.0, 0.06} };
    // Creating variables
    double userAmount = 0.0;
    double initBal = 0.0;
    double tempInt = 0.0;

    // Welcome
    cout << "Welcome to the bank." << endl;
    // Looping through accounts
    for (int i = 0; i < SIZE; i++) {
        // Withdrawl prompt and list user balance
        cout << "How much money do you wish to withdraw from account #" << (i + 1) << "?" << endl;
        cout << "Current balance: " << accounts[i]->getInitialBalance() << endl;
        cin >> userAmount;
        // Withdraw userAmount
        accounts[i]->debit(userAmount);
        // Get initBal
        initBal = accounts[i]->getInitialBalance();
        // Deposit prompt
        cout << "How much money do you wish to deposit to account #" << (i + 1) << "?" << endl;
        cin >> userAmount;
        // Deposit userAmount
        accounts[i]->credit(userAmount);
        // Test if account is a savings account using initBal
        if ((initBal + userAmount) == accounts[i]->getInitialBalance()) {
            // Create temporary SavingsAccount
            SavingsAccount *tempSAc = static_cast<SavingsAccount *>(accounts[i]);
            // Display calculateInterest
            cout << "Your account is owed " << tempSAc->calculateInterest() << "." << endl;
            // Store temporary interest in tempInt and credit current account
            tempInt = tempSAc->calculateInterest();
            accounts[i]->credit(tempInt);
            // Display current balance
            cout << "Current balance: " << accounts[i]->getInitialBalance() << endl << endl;
        }
        // If account is checking account then display current balance
        else {
            cout << "Current balance: " << accounts[i]->getInitialBalance() << endl << endl;
        }
    }

    */

    // ---------------------------------------------
    //                  Third Test
    // ---------------------------------------------

    /*
    
    // Creating accounts2 array
    const int SIZE2 = 4;
    Account* accounts2[SIZE2] = { new CheckingAccount{100.0, 5.0},
                                  new SavingsAccount{100.0, 5.0},
                                  new CheckingAccount{100.0, 5.0},
                                  new SavingsAccount{100.0, 5.0} };

    // Creating variables
    bool isChecking;
    double tempBal = 0.0;
    const double TEMPTEST = 10.0;
    double userInput = 0.0;

    // Welcome
    cout << "Welcome to the bank." << endl;
    cout << left << fixed;

    // Loop through accounts
    for (int i = 0; i < SIZE2; i++) {
        // Test whether account is checking account or not by testing credit
        isChecking = 1;
        tempBal = accounts2[i]->getInitialBalance();
        accounts2[i]->credit(TEMPTEST);
        if ((tempBal + TEMPTEST) == accounts2[i]->getInitialBalance()) {
            isChecking = 0;
        }
        // Prompt information
        cout << "What is the information inside of account #" << (i + 1) << "?" << endl;
        // Set initial balance
        cout << "Initial balance: ";
        cin >> userInput;
        accounts2[i]->setInitialBalance(userInput);
        // Checking test
        if (isChecking == 1) {
            // Set transaction fee
            cout << setprecision(2) << "Transaction fee: ";
            cin >> userInput;
            static_cast<CheckingAccount *>(accounts2[i])->setTransactionFee(userInput);
            // Display checking account
            cout << "Checking Account #" << (i + 1) << endl;
            cout << setw(18) << "Initial balance: " << "$" << accounts2[i]->getInitialBalance() << endl;
            cout << setw(18) << "Transaction fee: " << "$" << static_cast<CheckingAccount *>(accounts2[i])->getTransactionFee() << endl << endl;
        }
        // Savings
        else {
            // Set interest rate
            cout << setprecision(2) << "Interest rate: ";
            cin >> userInput;
            static_cast<SavingsAccount *>(accounts2[i])->setInterestRate(userInput);
            // Display savings account
            cout << "Checking Account #" << (i + 1) << endl;
            cout << setw(18) << "Initial balance: " << "$" << accounts2[i]->getInitialBalance() << endl;
            cout << setw(18) << "Interest rate: " << setprecision(0) << (100 * static_cast<SavingsAccount*>(accounts2[i])->getInterestRate()) 
                 << "%" << endl << endl;
        }
    }

    */

}