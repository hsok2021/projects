#include "account.h"
#include "savingsaccount.h"

// Getters and setters
double SavingsAccount::getInterestRate() {
	return interestRate;
}
void SavingsAccount::setInterestRate(double intRate) {
	// Validation so that interestRate cannot be more than 1.0 or less than 0
	if (intRate <= 1.0 && intRate >= 0) {
		interestRate = intRate;
	}
	else {
		interestRate = 0.05;
	}
}
// Utilities
// calculateInterest will calculate the interest owed by multiplying initialBalance by interestRate
double SavingsAccount::calculateInterest() {
	return getInitialBalance() * interestRate;
}