#include "account.h"
#include "checkingaccount.h"

// Getters and setters
double CheckingAccount::getTransactionFee() {
	return transactionFee;
}
void CheckingAccount::setTransactionFee(double transFee) {
	// Validation so that transactionFee cannot be less than 0
	if (transFee >= 0) {
		transactionFee = transFee;
	}
	else {
		transactionFee = 0.0;
	}
}
// Utilities
// Overridden credit that subtracts transactionFee from the account after deposit
void CheckingAccount::credit(double amount) {
	if (amount > 0 && ((getInitialBalance() + amount) - transactionFee) >= 0 ) {
		setInitialBalance((getInitialBalance() + amount) - transactionFee);
	}
	else {
		return;
	}
}
// Overridden debit that subtracts transactionFee from the account after withdrawl
void CheckingAccount::debit(double amount) {
	if (((getInitialBalance() - amount) - transactionFee) >= 0) {
		setInitialBalance((getInitialBalance() - amount) - transactionFee);
	}
	else {
		return;
	}
}