#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account {
	private:
		double initialBalance;

	public:
		// Constructors
		Account(double initBal) {
			// Validation so that initialBalance cannot be less than 0
			if (initBal >= 0) {
				initialBalance = initBal;
			}
			else {
				initialBalance = 100.0;
			}
		}
		Account() {
			initialBalance = 0.0;
		}
		// Methods
		// Getters and setters
		double getInitialBalance();
		void setInitialBalance(double initBal);
		// Utility
		virtual void credit(double amount);
		virtual void debit(double amount);

};

#endif