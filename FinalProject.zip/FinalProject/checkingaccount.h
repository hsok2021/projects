#ifndef CHECKINGACCOUNT_H
#define CHECKINGACCOUNT_H

#include "account.h"

class CheckingAccount: public Account {
	private:
		double transactionFee;
	public:
		// Constructors
		CheckingAccount(double initBal, double transFee) : Account(initBal) {
			setInitialBalance(initBal);
			// Validation so that transactionFee cannot be less than 0
			if (transFee >= 0) {
				transactionFee = transFee;
			}
			else {
				transactionFee = 0.0;
			}
		}
		CheckingAccount() : Account() {
			transactionFee = 0.0;
		}
		// Methods
		// Getters and setters
		double getTransactionFee();
		void setTransactionFee(double transFee);
		// Utilities
		virtual void credit(double amount);
		virtual void debit(double amount);

};

#endif