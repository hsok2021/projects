#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

#include "account.h"

class SavingsAccount: public Account {
	private:
		double interestRate;
	public:
		// Constructors
		SavingsAccount(double initBal, double intRate): Account(initBal) {
			setInitialBalance(initBal);
			// Validation so that interestRate cannot be more than 1.0 or less than 0
			if (intRate <= 1.0 && intRate >= 0) {
				interestRate = intRate;
			}
			else {
				interestRate = 0.05;
			}
		}
		SavingsAccount(): Account() {
			interestRate = 0.0;
		}
		// Methods
		// Getters and setters
		double getInterestRate();
		void setInterestRate(double intRate);
		// Utilities
		double calculateInterest();
		
};

#endif