#include "account.h"

// Getters and setters
double Account::getInitialBalance() {
	return initialBalance;
}
void Account::setInitialBalance(double initBal) {
	// Validation so that initialBalance cannot be less than 0
	if (initBal >= 0) {
		initialBalance = initBal;
	}
	else {
		initialBalance = 100.0;
	}
}
// Utilities
// credit deposits money into account, if amount is negative then function will return
void Account::credit(double amount) {
	if (amount >= 0) {
		initialBalance += amount;
	}
	else {
		return;
	}
}
// debit withdraws money from account, if amount withdrawn is more than the amount of money in the account then function will return
void Account::debit(double amount) {
	if ((getInitialBalance() - amount) >= 0) {
		initialBalance -= amount;
	}
	else {
		return;
	}
}