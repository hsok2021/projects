/*
Author: Hunter Sokolis
Date: 11/13/2023
Instructor: Mariusz Glayds
Course: CIS-2571
Description: Program tries to create a very large array and will catch and handle an OutOfMemoryError if it is too large.
 */

public class HS_Lab12 {
	public static void main(String[] args) {
		System.out.println("Trying to create a very large array...");
		try {
			final int[] bigArray = new int[Integer.MAX_VALUE];
		}
		catch (OutOfMemoryError err) {
			System.out.println("This array is too large!");
		}
		System.out.println("Continues");
	}
}