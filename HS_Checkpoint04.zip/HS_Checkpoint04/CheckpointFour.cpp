// ----------------------
// CIS2542 - Checkpoint 4
// ----------------------
#include <iostream>
#include <deque>
#include <vector>

void PartOne()
{
    // - - - - - - - - - - - - - - - - - - - - - - -
    // #0 OF 10
    // PLEASE REPLACE MY NAME WITH YOUR NAME INSTEAD 
    // - - - - - - - - - - - - - - - - - - - - - - -
    std::cout << "----------------------------------------" << std::endl;
    std::cout << "HUNTER SOKOLIS'S SOLUTION TO CHECKPOINT 4" << std::endl;
    std::cout << "----------------------------------------" << std::endl << std::endl;

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #1 OF 10
    // USE A LOOP TO SET UP VECTOR a WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    // PUT EACH ELEMENT IN THE FRONT AS YOU ADD THEM TO THE VECTOR (PUT 1 IN FIRST)
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::vector<int> a;

    // USE A LOOP TO SET UP VECTOR a WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    for (int i = 1; i <= 500000; ++i)
    {
        // PUT EACH ELEMENT IN THE FRONT AS YOU ADD THEM TO THE VECTOR (PUT 1 IN FIRST)
        a.insert(a.begin(), i);
    }
            
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #2 OF 10
    // USE A LOOP TO SET UP VECTOR b WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    // FIRST USE THE reserve() FUNCTION THAT IS PART OF THE VECTOR'S API
    // PUT EACH ELEMENT IN THE FRONT AS YOU ADD THEM TO THE VECTOR (PUT 1 IN FIRST)
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::vector<int> b;
    b.reserve(500000);
    for (int i = 1; i <= 500000; ++i) {
        b.insert(b.begin(), i);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #3 OF 10
    // USE A LOOP TO SET UP DEQUE c WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    // PUT EACH ELEMENT IN THE FRONT AS YOU ADD THEM TO THE DEQUE (PUT 1 IN FIRST)
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::deque<int> c;
    for (int i = 1; i <= 500000; ++i) {
        c.push_front(i);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #4 OF 10
    // FULLY DESCRIBE AND COMPARE THE SPEEDS IN WHICH THE THREE OPERATIONS WILL PERFORM
    // THEIR DUTIES AND WHY.  EITHER USE A COMMENT, OR PRINT YOUR DESCRIPTION TO THE SCREEN
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    /*
    Step #1 takes the longest because you need to recreate and resize the underlying array each time you hit the end of it, and each time you add an element to the
    front, you must move all other elements over.

    Step #2 takes less time because the array's space is already reserved, but it still takes time to move all of the elements over.

    Step #3 takes the least time because even though more space must be added each time the deque hits its limit, elements do not need to be moved over which
    lightens the load.
    */
}

void PartTwo()
{
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #5 OF 10
    // USE A LOOP TO SET UP VECTOR a WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    // PUT EACH ELEMENT IN THE BACK AS YOU ADD THEM TO THE VECTOR (PUT 1 IN FIRST)
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::vector<int> a;
    for (int i = 1; i <= 500000; ++i) {
        a.push_back(i);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #6 OF 10
    // USE A LOOP TO SET UP DEQUE b WITH 500000 ELEMENTS IN ORDER 1, 2, 3, 4, ..., 500000
    // PUT EACH ELEMENT IN THE BACK AS YOU ADD THEM TO THE DEQUE (PUT 1 IN FIRST)
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::deque<int> b;
    for (int i = 1; i <= 500000; ++i) {
        b.push_back(i);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #7 OF 10
    // FULLY DESCRIBE WHICH OF THE TWO OPERATIONS IS FASTER THAN THE OTHER AND WHY
    // EITHER USE A COMMENT, OR PRINT YOUR DESCRIPTION TO THE SCREEN
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    /*
    Step #5 will take the longest because of the way vectors store information. Vectors store information in a continuous block of memory, whereas deques create
    space in different memory locations which ends up taking less time to resize.
    */
}

void PartThree()
{
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #8 OF 10
    // INSERT VALUES {6, 7, 8, 9} BETWEEN THE 2 AND THE 3 VALUES IN THE VECTOR a
    // FOR EXAMPLE 1,2,3,4,5 BECOMES 1,2,6,7,8,9,3,4,5
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::vector<int> a { 1, 2, 3, 4, 5 };
    a.insert((a.begin() + 2), 9);
    a.insert((a.begin() + 2), 8);
    a.insert((a.begin() + 2), 7);
    a.insert((a.begin() + 2), 6);

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #9 OF 10
    // INSERT VALUES {6, 7, 8, 9} BETWEEN THE 2 AND THE 3 VALUE IN THE DEQUE b
    // FOR EXAMPLE 1,2,3,4,5 BECOMES 1,2,6,7,8,9,3,4,5
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    std::deque<int *> b { new int(1), new int(2), new int(3), new int(4), new int(5) };
    b.insert((b.begin() + 2), new int(9));
    b.insert((b.begin() + 2), new int(8));
    b.insert((b.begin() + 2), new int(7));
    b.insert((b.begin() + 2), new int(6));

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // #10 OF 10
    // PROPERLY EMPTY/CLEAR OUT THE VECTOR a
    // PROPERLY EMPTY/CLEAR OUT THE DEQUE b
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    a.clear();
    for (int* item : b) {
        delete(item);
    }
    b.clear();
}

// ---------------------------------
// You may not touch this code below
// ---------------------------------
int main()
{
    // Work with the fronts of the vector and deque data structures
    PartOne();

    // Work with the backs of the vector and deque data structures
    PartTwo();

    // Work with inserting and clearing the vector and deque data structures
    PartThree();

    // Cleanup
    system("PAUSE");
    return 0;
}