/*
Application Name: Basic Math Calculator
Assignment Number: Unit 3 Assignment 1
Version: 1.0
Description: Program will prompt user for two integers. Program will then perform addition, multiplication, subtraction, division, and division with remainder
on the two integers and display output.
Input: Integer
Output: Integer, Double

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/10/2022
*/

#include <iostream>
using namespace std;

int main()
{
    // Data storage
    int integer1, integer2, sum, product, difference;
    double quotient, modulus;

    // User prompt
    cout << "Please enter two integers separated by a space." << endl;
    cin >> integer1 >> integer2;

    // Calculation
    sum = integer1 + integer2;
    product = integer1 * integer2;
    difference = integer1 - integer2;
    quotient = integer1 / integer2;
    modulus = integer1 % integer2;

    // Calculation output
    cout << "Sum: " << sum << endl
         << "Product: " << product << endl
         << "Difference: " << difference << endl
         << "Quotient: " << quotient << endl
         << "Modulus: " << modulus;
    return 0;
}
