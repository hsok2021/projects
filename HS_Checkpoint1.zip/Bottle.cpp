#include "Bottle.h"

Bottle::Bottle(double filled)
	: fill(Clamp(filled))
{
	// empty
}

double Bottle::GetFillValue() const
{
	return fill;
}

void Bottle::ModifyFill(double filling)
{
	fill = Clamp(fill += filling);
}

bool Bottle::IsEmpty() const
{
	return fill == 0.0;
}

bool Bottle::IsFull() const
{
	return fill == 1.0;
}

double Bottle::Clamp(double filled) const
{
	if (filled < 0.0) {
		return 0.0;
	}
	if (filled > 1.0) {
		return 1.0;
	}
	return filled;
}
