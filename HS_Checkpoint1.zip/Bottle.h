#pragma once

class Bottle {
public:
	Bottle(double filled = 0.0);

	double GetFillValue() const;
	void ModifyFill(double filling);

	bool IsEmpty() const;
	bool IsFull() const;

private:
	double fill;

	double Clamp(double filled) const;
};