// -----------------------------------------------
// YOU MAY NOT MODIFY ANYTHING FOUND IN THIS FILE! 
// -----------------------------------------------

#include <cassert>
#include <iostream>
#include "Bottle.h"

int main()
{
	// TESTING DEFAULT PARAMETER STARTING AT MIN FILL VALUE AT CONSTRUCTION
	Bottle a;
	assert(a.GetFillValue() == 0.0);
	assert(a.IsEmpty() ==  true);
	assert(a.IsFull() == false);

	// TESTING CLAMP ON LOW SIDE AT CONSTRUCTION
	Bottle b(-8.2);
	assert(b.GetFillValue() == 0.0);
	assert(b.IsEmpty() == true);
	assert(b.IsFull() == false);

	// TESTING STARTING AT MAX FILL VALUE AT CONSTRUCTION
	Bottle c(1.0);
	assert(c.GetFillValue() == 1.0);
	assert(c.IsEmpty() == false);
	assert(c.IsFull() == true);

	// TESTING CLAMP ON HIGH SIDE AT CONSTRUCTION
	Bottle d(8.2);
	assert(d.GetFillValue() == 1.0);
	assert(d.IsEmpty() == false);
	assert(d.IsFull() == true);

	// TESTING VALUE BEING WITHIN ALLOWED RANGE AT CONSTRUCTION
	Bottle e(0.75);
	assert(e.GetFillValue() == 0.75);
	assert(e.IsEmpty() == false);
	assert(e.IsFull() == false);
	
	// -------------------------------------------------------
	// TESTING a FROM HERE ON OUT (STARTING AT FILL VALUE 0.0)
	// -------------------------------------------------------
	
	// TESTING POSITIVE FILL INTO ACCEPTABLE RANGE
	a.ModifyFill(0.50);
	assert(a.GetFillValue() == 0.50);
	assert(a.IsFull() == false);
	assert(a.IsEmpty() == false);

	// TESTING CLAMP ON THE HIGH SIDE
	a.ModifyFill(0.60);
	assert(a.GetFillValue() == 1.00);
	assert(a.IsFull() == true);
	assert(a.IsEmpty() == false);
	
	// TESTING NEGATIVE FILL INTO ACCEPTABLE RANGE
	a.ModifyFill(-0.50);
	assert(a.GetFillValue() == 0.50);
	assert(a.IsFull() == false);
	assert(a.IsEmpty() == false);

	// TESTING CLAMP ON LOW SIDE
	a.ModifyFill(-0.60);
	assert(a.GetFillValue() == 0.00);
	assert(a.IsFull() == false);
	assert(a.IsEmpty() == true);

	// IF YOU MAKE IT HERE THEN YOUR CLASS WORKS AS EXPECTED AND YOU
	// SHOULD SUBMIT THE THREE FILES YOU HAVE TO MAKE THIS ALL WORK!
	std::cout << "ALL TEST CASES PASSED!!!" << std::endl;
	return 0;
}