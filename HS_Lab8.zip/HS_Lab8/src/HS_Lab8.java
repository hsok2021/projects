/*
Author: Hunter Sokolis
Date: 10/13/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program will ask the user to input data for 8 employees. The program will then sort this data by hours and then
display it to the screen.
 */

import java.util.*;

public class HS_Lab8 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		final int EMPLOYEEAMOUNT = 8;
		final int ITEMAMOUNT = 9;
		String[][] employees = new String[EMPLOYEEAMOUNT][ITEMAMOUNT];
		int employeeTotal = 0;
		
		// prompt
		for (int i = 0; i < EMPLOYEEAMOUNT; i++) {
			System.out.print("Please enter the name of employee " + (i + 1) + ": ");
			employees[i][0] = input.nextLine();
			System.out.print("Please enter Sunday's hours for employee " + (i + 1) + ": ");
			employees[i][1] = input.nextLine();
			System.out.print("Please enter Monday's hours for employee " + (i + 1) + ": ");
			employees[i][2] = input.nextLine();
			System.out.print("Please enter Tuesday's hours for employee " + (i + 1) + ": ");
			employees[i][3] = input.nextLine();
			System.out.print("Please enter Wednesday's hours for employee " + (i + 1) + ": ");
			employees[i][4] = input.nextLine();
			System.out.print("Please enter Thursday's hours for employee " + (i + 1) + ": ");
			employees[i][5] = input.nextLine();
			System.out.print("Please enter Friday's hours for employee " + (i + 1) + ": ");
			employees[i][6] = input.nextLine();
			System.out.print("Please enter Saturday's hours for employee " + (i + 1) + ": ");
			employees[i][7] = input.nextLine();
		}
		
		// total calculation
		for (String[] employee : employees) {
			employeeTotal = 0;
			for (int i = 1; i < (ITEMAMOUNT - 1); i++) {
				employeeTotal += Integer.parseInt(employee[i]);
			}
			employee[8] = Integer.toString(employeeTotal);
		}
		
		// sort
		int sortMover = EMPLOYEEAMOUNT - 1;
		int lowestIndex = 0;
		for (int i = 0; i < EMPLOYEEAMOUNT; i++) {
			lowestIndex = 0;
			for (int e = 0; e <= sortMover; e++) {
				if (Integer.parseInt(employees[e][8])   <   Integer.parseInt(employees[lowestIndex][8])) {
					lowestIndex = e;
				}
			}
			String[] tempValue = employees[sortMover];
			employees[sortMover] = employees[lowestIndex];
			employees[lowestIndex] = tempValue;
			sortMover--;
		}
		
		// display
		for (String[] employee : employees) {
			System.out.println("Hours for " + employee[0] + ": " + employee[8]);
		}
	}
}
