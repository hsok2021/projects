/*
Author: Hunter Sokolis
Date: 10/13/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program prompts user to enter numbers less than 20 until they wish to stop. Once done, the program will print
the values and their distance from the average of the sum of them.
 */

import java.util.*;


public class HS_Lab7 {
	public static void main(String[] args) {
		double[] numbers = new double[1];
		int arraySize = 0;
		double userNum;
		double average = 0.0;
		Scanner input = new Scanner(System.in);
		
		do {
			System.out.print("Please enter any number less than or equal to 20 (Enter 99999 to quit): ");
			userNum = input.nextDouble();
			
			// increase array size
			if (arraySize == numbers.length && userNum != 99999 && userNum <= 20.0) {
				double[] tempArr = new double[numbers.length + 1];
				
				for (int i = 0; i < arraySize; i++) {
					tempArr[i] = numbers[i];
				}
				
				numbers = tempArr;
			}
			
			// cases
			if (userNum <= 20.0) {
				numbers[arraySize] = userNum;
				average += userNum;
				++arraySize;
			}
			else if (userNum == 99999 && arraySize == 0) {
				do {
					System.out.print("You cannot leave the array empty. Please enter a number: ");
					userNum = input.nextDouble();
					if (userNum <= 20.0) {
						numbers[arraySize] = userNum;
						average += userNum;
						++arraySize;
					}
				} while (userNum == 99999);
			}
			
		} while (userNum != 99999.0);
		input.close();
		
		// display
		average /= arraySize;
		System.out.println("Average");
		System.out.println(average);
		System.out.println("Number   Distance from average");
		for(double number : numbers) {
			System.out.println(number + "      " + Math.abs(number - average));
		}
	}
}
