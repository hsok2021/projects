/*
Application Name: Hardware Invoice Bank
Assignment Number: Unit 14 Assignment 1
Version: 1.0
Description: Takes an array of invoices and sorts them by description in ascending order, by price in descending order, and then displays the
             invoice totals in ascending order.
Input: None
Output: String

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 11/29/2022
*/

#include <iostream>
#include "Invoice.h"
using namespace std;

int main()
{
    // Creation of invoices array
    const int SIZE = 8;
    Invoice invoices[SIZE] = { Invoice{83, "Electric sander", 7, 57.98},
                           Invoice{24, "Power saw", 18, 99.99},
                           Invoice{7, "Sledge hammer", 11, 21.5},
                           Invoice{77, "Hammer", 76, 11.99},
                           Invoice{39, "Lawn mower", 3, 79.5},
                           Invoice{68, "Screwdriver", 106, 6.99},
                           Invoice{56, "Jig saw", 21, 11.00},
                           Invoice{3, "Wrench", 34, 7.5} };

    // Welcome and program display
    cout << "This is the Invoice System." << endl;
    cout << "Parts sorted by description in ascending order:" << endl << "-----" << endl;
    invoices->sortByPartDesc(invoices, SIZE);
    cout << endl;
    cout << "Parts sorted by price in descending order:" << endl << "-----" << endl;
    invoices->sortByPrice(invoices, SIZE);
    cout << endl;
    cout << "Parts sorted by invoice total in ascending order:" << endl << "-----" << endl;
    invoices->displayInvoice(invoices, SIZE);
}