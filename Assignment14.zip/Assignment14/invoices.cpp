// Creation of class implementation
#include <iostream>
#include <vector>
#include <iomanip>
#include "Invoice.h"

// sortByPartDesc, sorts array by part descriptions in ascending order
void Invoice::sortByPartDesc(Invoice invoices[], const int SIZE) {

	// Initialize checkNum, temp, and tempInvoice
	int checkNum = 0;
	int temp = 0;
	Invoice tempInvoice = Invoice(0, "", 0, 0.0);

	// Loop through array multiple times
	for (int e = 0; e < SIZE; e++) {
		// Reset temp and tempInvoice values to checkNum
		temp = checkNum;
		tempInvoice = invoices[checkNum];
		// Pass through array
		for (int i = checkNum; i < SIZE; i++) {
			// Test for greatest description value
			if (invoices[i].getDescription() < invoices[temp].getDescription()) {
				// Fill temp variables with temp values
				temp = i;
				tempInvoice = invoices[i];
			}
		}
		// Swap values between greatest value and checkNum value
		invoices[temp] = invoices[checkNum];
		invoices[checkNum] = tempInvoice;
		// Increment checkNum
		checkNum++;
	}

	// Display sort output
	std::cout << std::left;
	std::cout << std::setw(15) << "Part Number" << std::setw(20) << "Description" << std::setw(12) << "Quantity" << "Price" << std::endl;
	for (int i = 0; i < SIZE; i++) {
		std::cout << std::setw(15) << invoices[i].getNumber() << std::setw(20) << invoices[i].getDescription() << std::setw(12) <<
			         invoices[i].getQuantity() << invoices[i].getPrice() << std::endl;
	}
}

// sortByPrice, sorts array by price in descending order
void Invoice::sortByPrice(Invoice invoices[], const int SIZE) {

	// Initialize temp
	Invoice temp = Invoice(0, "", 0, 0.0);

	// Loop through array multiple times
	for (int e = 0; e < SIZE; e++) {
		// Pass through the array
		for (int i = 1; i < SIZE; i++) {
			// Test for least value
			if (invoices[i - 1].getPrice() < invoices[i].getPrice()) {
				// Swap positions between value in current index and value in previous index
				temp = invoices[i];
				invoices[i] = invoices[i - 1];
				invoices[i - 1] = temp;
			}
		}
	}

	// Display sort output
	std::cout << std::left;
	std::cout << std::setw(15) << "Part Number" << std::setw(20) << "Description" << std::setw(12) << "Quantity" << "Price" << std::endl;
	for (int i = 0; i < SIZE; i++) {
		std::cout << std::setw(15) << invoices[i].getNumber() << std::setw(20) << invoices[i].getDescription() << std::setw(12) <<
			invoices[i].getQuantity() << invoices[i].getPrice() << std::endl;
	}
}

// calculateInvoicesTotal, calculate the totals of individual invoices
void Invoice::calculateInvoicesTotal(Invoice invoices[], std::vector<double> &invoiceTotals, const int SIZE) {
	// Clear invoices at the beginning
	invoiceTotals.clear();
	// Calculate invoice totals and push to totals vector
	for (int i = 0; i < SIZE; i++) {
		invoiceTotals.push_back(invoices[i].getPrice() * invoices[i].getQuantity());
	}
}

// displayInvoice, display the invoice totals in ascending order
void Invoice::displayInvoice(Invoice invoices[], const int SIZE) {

	// Create vector to store totals and call calculateInvoicesTotal
	std::vector<double> totals;
	invoices->Invoice::calculateInvoicesTotal(invoices, totals, SIZE);

	// Initialize tempInvoice and tempTotal
	Invoice tempInvoice = Invoice(0, "", 0, 0.0);
	double tempTotal = 0.0;

	// Loop through the array multiple times
	for (int e = 0; e < SIZE; e++) {
		// Pass through the array
		for (int i = 1; i < SIZE; i++) {
			// Test whether previous totals index is greater than current totals index
			if (totals[i - 1] > totals[i]) {
				// Swap totals and invoices
				tempTotal = totals[i];
				tempInvoice = invoices[i];
				invoices[i] = invoices[i - 1];
				invoices[i - 1] = tempInvoice;
				totals[i] = totals[i - 1];
				totals[i - 1] = tempTotal;
			}
		}
	}

	// Display sort output
	std::cout << std::left;
	std::cout << std::setw(15) << "Part Number" << std::setw(20) << "Description" << std::setw(12) << "Quantity" << std::setw(9) << "Price" 
		      << "Invoice Total" << std::endl;
	for (int i = 0; i < SIZE; i++) {
		std::cout << std::setw(15) << invoices[i].getNumber() << std::setw(20) << invoices[i].getDescription() << std::setw(12) <<
			invoices[i].getQuantity() << std::setw(9) << invoices[i].getPrice() << totals[i] << std::endl;
	}

}