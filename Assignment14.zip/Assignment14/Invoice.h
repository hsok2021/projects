// Creation of class definition
#ifndef INVOICE_H
#define INVOICE_H

#include <string>
#include <vector>

class Invoice
{
	// Private members
	private:
		int number;
		std::string description;
		int quantity;
		double price;

	// Public members
	public:
		// Constructors
		Invoice() {
			number = 0;
			description = "";
			quantity = 0;
			price = 0.0;
		}

		Invoice(int num, std::string desc, int amt, double cost) {
			number = num;
			description = desc;
			quantity = amt;
			price = cost;
		}

		// Utility functions
		void sortByPartDesc(Invoice invoices[], const int SIZE);
		void sortByPrice(Invoice invoices[], const int SIZE);
		void calculateInvoicesTotal(Invoice invoices[], std::vector<double> &totals, const int SIZE);
		void displayInvoice(Invoice invoices[], const int SIZE);

		// Getters and setters
		int getNumber() {
			return number;
		}
		void setNumber(int num) {
			number = num;
		}
		std::string getDescription() {
			return description;
		}
		void setDescription(std::string desc) {
			description = desc;
		}
		int getQuantity() {
			return quantity;
		}
		void setQuantity(int amt) {
			quantity = amt;
		}
		double getPrice() {
			return price;
		}
		void setPrice(double cost) {
			price = cost;
		}
};

#endif