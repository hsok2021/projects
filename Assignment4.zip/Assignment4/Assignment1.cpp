/*
Application Name: Sea Mobile Monthly Bill Calculator
Assignment Number: Unit 4 Assignment 1
Version: 1.0
Description: Program will calculate customer's monthly bill. Program will ask user for plan used and gigabytes used and then calculate and display total.
Input: Char, Double
Output: Double

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/14/2022
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    // Data storage
    double gbUsed, gbOver, total;
    const double ACHARGE = 39.99, BCHARGE = 59.99, CCHARGE = 69.99, AGIGS = 4.0, BGIGS = 8.0, AOVER = 10.0, BOVER = 5.0;
    char planUsed;

    // Data input
    cout << "How many gigabytes of data have you used this month?" << endl;
    cin >> gbUsed;

    cout << "Which Sea plan do you use? (A, B, or C. Single characters only)" << endl;
    cin >> planUsed;

    // Calculate for plan and display
    if (toupper(planUsed) == 'A') {

        // Calculate gbOver
        gbOver = gbUsed - AGIGS;
        if (gbOver <= 0.0)
            gbOver = 0.0;

        total = ACHARGE + (gbOver * AOVER);
        cout << "Your monthly charge will be $" << fixed << showpoint << setprecision(2) << total << "." << endl;
    }
    else if (toupper(planUsed) == 'B') {

        // Calculate gbOver
        gbOver = gbUsed - BGIGS;
        if (gbOver <= 0.0)
            gbOver = 0.0;

        total = BCHARGE + (gbOver * BOVER);
        cout << "Your monthly charge will be $" << fixed << showpoint << setprecision(2) << total << "." << endl;
    }
    else if (toupper(planUsed) == 'C') {

        total = CCHARGE;
        cout << "Your monthly charge will be $" << fixed << showpoint << setprecision(2) << total << "." << endl;
    }
    // Incorrect input handler
    else {
        cout << "\"" << planUsed << "\" is not a valid plan. The only valid plans are A, B, or C." << endl;
    }

    return 0;
}

