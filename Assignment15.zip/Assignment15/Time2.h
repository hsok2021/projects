#ifndef TIME2_h
#define TIME2_h

class Time2 {
	private:
		// Members
		int hour;
		int minute;
		int second;

	public:
		// Constructors
		Time2() {
			hour = 0;
			minute = 0;
			second = 0;
		}

		Time2(int hrs, int mins, int scnds) {
			hour = hrs;
			minute = mins;
			second = scnds;
		}

		// Methods
		// Utility functions
		double timeToDouble();

		// Getters and setters
		int getHour() {
			return hour;
		}
		void setHour(int hrs) {
			hour = hrs;
		}
		int getMinute() {
			return minute;
		}
		void setMinute(int mins) {
			minute = mins;
		}
		int getSecond() {
			return second;
		}
		void setSecond(int scnds) {
			second = scnds;
		}
};

#endif