/*
Application Name: Payroll Program
Assignment Number: Unit 15 Assignment 1
Version: 1.0
Description: Allows the user to enter their information and then calculates how many hours the user has worked and what their earnings are.
Input: String, Integer, Double
Output: Double, String

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 12/5/2022
*/

#include <iostream>
#include <string>
#include "TimeCard.h"
#include "Time2.h"
using namespace std;

int main()
{
    // Variables
    string userChoice = "1";
    string userWorkerID = "000000000";
    int userPunchInHour = 0;
    int userPunchInMinute = 0;
    int userPunchInSecond = 0;
    int userPunchOutHour = 0;
    int userPunchOutMinute = 0;
    int userPunchOutSecond = 0;
    double userPayrate = 0.0;

    // User welcome
    cout << "Welcome to the Payment Program." << endl;
    // User loop
    do {
        // Social security number
        cout << "Please enter the employee's" << endl;
        cout << "Social security number: ";
        cin >> userWorkerID;

        // Punch in time
        // User cannot punch in before 8 or after 4 (16) (4 because user can enter 59 for minutes and seconds)
        do {
            cout << "Start time hour (in 24 hours): ";
            cin >> userPunchInHour;
            // Error message
            if (userPunchInHour < 8 || userPunchInHour > 16)
                cout << "That's not a valid hour. ";
        } while (userPunchInHour < 8 || userPunchInHour > 16);
        // User cannot enter a number below 0 or above 59
        do {
            cout << "Minute: ";
            cin >> userPunchInMinute;
            // Error message
            if (userPunchInMinute < 0 || userPunchInMinute > 59)
                cout << "That's not a valid minute. ";
        } while (userPunchInMinute < 0 || userPunchInMinute > 59);
        // User cannot enter a number below 0 or above 59
        do {
            // Error message
            if (userPunchInSecond < 0 || userPunchInSecond > 59)
                cout << "That's not a valid second. ";
            cout << "Second: ";
            cin >> userPunchInSecond;
        } while (userPunchInSecond < 0 || userPunchInSecond > 59);

        // Punch out time
        // User cannot punch out before 8 or after 4 (16) (4 because user can enter 59 for minutes and seconds), user also cannot enter an hour
        // before their punch in hour
        do {
            cout << "End time hour (in 24 hours): ";
            cin >> userPunchOutHour;
            // Error message
            if ((userPunchOutHour < 8 || userPunchOutHour > 16) || (userPunchOutHour < userPunchInHour))
                cout << "That's not a valid hour. ";
        } while ((userPunchOutHour < 8 || userPunchOutHour > 16) || (userPunchOutHour < userPunchInHour));
        // User cannot enter a number below 0 or above 59, user also cannot enter a minute before their punch in minute if they clocked in and out
        // during the same hour
        do {
            cout << "Minute: ";
            cin >> userPunchOutMinute;
            // Error message
            if ((userPunchOutMinute < 0 || userPunchOutMinute > 59) || ((userPunchOutHour == userPunchInHour) && (userPunchOutMinute < userPunchInMinute)))
                cout << "That's not a valid minute. ";
        } while ((userPunchOutMinute < 0 || userPunchOutMinute > 59) || ((userPunchOutHour == userPunchInHour) && (userPunchOutMinute < userPunchInMinute)));
        // User cannot enter a number below 0 or above 59, user also cannot enter a second before their punch in second if they clocked in and out
        // during the same hour and at the same minute
        do {
            cout << "Second: ";
            cin >> userPunchOutSecond;
            // Error message
            if ((userPunchOutSecond < 0 || userPunchOutSecond > 59) || ((userPunchOutHour == userPunchInHour) && (userPunchOutMinute == userPunchInMinute) && (userPunchOutSecond < userPunchInSecond)))
                cout << "That's not a valid second. ";
        } while ((userPunchOutSecond < 0 || userPunchOutSecond > 59) || ((userPunchOutHour == userPunchInHour) && (userPunchOutMinute == userPunchInMinute) && (userPunchOutSecond < userPunchInSecond)));

        // Pay rate
        // User cannot enter a negative number
        do {
            // Error message
            if (userPayrate < 0)
                cout << "That's not a valid payrate. ";
            cout << "Pay rate: ";
            cin >> userPayrate;
        } while (userPayrate < 0);

        // Create user TimeCard
        TimeCard user = { userWorkerID, {userPunchInHour, userPunchInMinute, userPunchInSecond}, {userPunchOutHour, userPunchOutMinute, userPunchOutSecond}, userPayrate, 1 };
        // Hours and earnings output
        cout << "You have worked " << user.getHoursWorked() << " hours today." << endl;
        cout << "You will be paid $" << user.getEarnings() << "." << endl;
        // User continue
        cout << "Do you wish to enter another user? Enter '0' to stop." << endl;
        cin >> userChoice;
    } while (userChoice != "0");
}