#include "Time2.h"
#include "TimeCard.h"

// getHoursWorked returns the hours worked in floating point format
double TimeCard::getHoursWorked() {
	// Return punchOutTime - punchInTime
	return (punchOutTime.timeToDouble() - punchInTime.timeToDouble());
}

// getEarnings returns the earnings made
double TimeCard::getEarnings() {
	// return hours worked * payrate
	return (getHoursWorked() * getPayrate());
}