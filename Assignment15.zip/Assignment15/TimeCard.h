#ifndef TIMECARD_H
#define TIMECARD_H
#include "Time2.h"
#include <string>

class TimeCard {
	private:
		// Members
		std::string workerID;
		Time2 punchInTime;
		Time2 punchOutTime;
		double payrate;
		bool hasPunched;

	public:
		// Constructors
		TimeCard() {
			workerID = "000000000";
			punchInTime = { 0, 0, 0 };
			punchOutTime = { 0, 0, 0 };
			payrate = 0.0;
			hasPunched = 0;
		}

		TimeCard(std::string id, Time2 punchIn, Time2 punchOut, double rate, bool punched) {
			workerID = id;
			punchInTime = punchIn;
			punchOutTime = punchOut;
			payrate = rate;
			hasPunched = punched;
		}

		// Methods
		// Utility functions
		double getHoursWorked();
		double getEarnings();

		// Getters and setters
		std::string getWorkerID() {
			return workerID;
		}
		void setWorkerID(std::string id) {
			workerID = id;
		}
		Time2 getPunchInTime() {
			return punchInTime;
		}
		void setPunchInTime(Time2 punchIn) {
			punchInTime = punchIn;
		}
		Time2 getPunchOutTime() {
			return punchOutTime;
		}
		void setPunchOutTime(Time2 punchOut) {
			punchInTime = punchOut;
		}
		double getPayrate() {
			return payrate;
		}
		void setPayrate(double rate) {
			payrate = rate;
		}
		bool getHasPunched() {
			return hasPunched;
		}
		void setHasPunched(bool punched) {
			hasPunched = punched;
		}
};

#endif