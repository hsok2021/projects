#include "Time2.h"
#include "TimeCard.h"

// timeToDouble converts Time into floating point format
double Time2::timeToDouble() {
	// Return time by making hours a whole number, but converting minutes to a decimal and divide seconds by 60 twice
	return (static_cast<double>(getHour())) + (static_cast<double>(getMinute()) / 60.0) + ((static_cast<double>(getSecond()) / 60.0) / 60.0);
}