/*
Author: Hunter Sokolis
Date: 12/10/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program allows you to change the lights on the traffic light to red, yellow, or green.
 */

package application;
	
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		//setting up radio buttons
		HBox hBox = new HBox();
    	hBox.setSpacing(5);
    	hBox.setAlignment(Pos.CENTER);
    	RadioButton rbRed = new RadioButton();
    	RadioButton rbYellow = new RadioButton();
    	RadioButton rbGreen = new RadioButton();
    	BorderPane paneRed = new BorderPane();
    	BorderPane paneYellow = new BorderPane();
    	BorderPane paneGreen = new BorderPane();
    	paneRed.setRight(new Label(" Red"));
    	paneYellow.setRight(new Label(" Yellow"));
    	paneGreen.setRight(new Label(" Green"));
    	paneRed.setLeft(rbRed);
    	paneYellow.setLeft(rbYellow);
    	paneGreen.setLeft(rbGreen);
    	hBox.getChildren().addAll(paneRed, paneYellow, paneGreen);
    	
    	//only select 1
    	ToggleGroup group = new ToggleGroup();
    	rbRed.setToggleGroup(group);
    	rbYellow.setToggleGroup(group);
    	rbGreen.setToggleGroup(group);
    	
    	//traffic light
    	Group lightGroup = new Group();
    	Rectangle lightRect = new Rectangle(34, 98);
    	Circle lightRed = new Circle();
    	Circle lightYellow = new Circle();
    	Circle lightGreen = new Circle();
    	//rect
    	lightRect.setStroke(Color.BLACK);
    	lightRect.setFill(Color.BLACK);
    	//red
    	lightRed.setRadius(15);
    	lightRed.setCenterX(17);
    	lightRed.setCenterY(17);
    	lightRed.setStroke(Color.BLACK);
    	lightRed.setFill(Color.GRAY);
    	//yellow
    	lightYellow.setRadius(15);
    	lightYellow.setCenterX(17);
    	lightYellow.setCenterY(49);
    	lightYellow.setStroke(Color.BLACK);
    	lightYellow.setFill(Color.GRAY);
    	//green
    	lightGreen.setRadius(15);
    	lightGreen.setCenterX(17);
    	lightGreen.setCenterY(81);
    	lightGreen.setStroke(Color.BLACK);
    	lightGreen.setFill(Color.GRAY);
    	
    	lightGroup.getChildren().addAll(lightRect, lightRed, lightYellow, lightGreen);
    	
    	
    	//change color
    	rbRed.setOnAction(e -> {
    		if (rbRed.isSelected()) {
    			lightRed.setFill(Color.RED);
    			lightYellow.setFill(Color.GRAY);
    			lightGreen.setFill(Color.GRAY);
    		}
    	});
    	
    	rbYellow.setOnAction(e -> {
    		if (rbYellow.isSelected()) {
    			lightRed.setFill(Color.GRAY);
    			lightYellow.setFill(Color.YELLOW);
    			lightGreen.setFill(Color.GRAY);
    		}
    	});
    	
    	rbGreen.setOnAction(e -> {
    		if (rbGreen.isSelected()) {
    			lightRed.setFill(Color.GRAY);
    			lightYellow.setFill(Color.GRAY);
    			lightGreen.setFill(Color.LIME);
    		}
    	});
    	
    	BorderPane borderPane = new BorderPane();
    	borderPane.setBottom(hBox);
    	BorderPane.setAlignment(hBox, Pos.CENTER);
    	borderPane.setCenter(lightGroup);
    	
    	Scene scene = new Scene(borderPane, 170, 170);
    	primaryStage.setTitle("Traffic Light");
    	primaryStage.setScene(scene);
    	primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
