
public class HS_Lab10 {
	public static void main(String[] args) {
		MyInteger test2 = new MyInteger(2);
		System.out.println(test2.getValue());
		System.out.println(test2.isEven());
		System.out.println(test2.isOdd());
		System.out.println(test2.isPrime());
		
		System.out.println(MyInteger.isEven(5));
		System.out.println(MyInteger.isOdd(7));
		System.out.println(MyInteger.isPrime(8));
		
		MyInteger test3 = new MyInteger(12);
		System.out.println(MyInteger.isEven(test3));
		System.out.println(MyInteger.isOdd(test3));
		System.out.println(MyInteger.isPrime(test3));
		
		System.out.println(test2.equals(2));
		System.out.println(test2.equals(test3));
		
		char[] test = {'1', '6', '3', '7', '2', '9'};
		System.out.println(MyInteger.parseInt(test));
		
		String test1 = "082681029";
		System.out.println(MyInteger.parseInt(test1));
	}
}
