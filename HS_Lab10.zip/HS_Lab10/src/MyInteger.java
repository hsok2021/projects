/*
Author: Hunter Sokolis
Date: 10/30/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: creates public class MyInteger which has getter method getValue(), boolean methods isEven(), isOdd(), isPrime(),
equals(int) and equals(MyInteger) which return whether values are equal, static methods parseInt(char[]) and parseInt(String)
which convert arguments into integers, and static int and MyInteger versions of isEven(), isOdd(), and isPrime().
 */

public class MyInteger {
	private int value;
	
	// constructor
	public MyInteger(int value) {
		this.value = value;
	}
	
	// methods
	public int getValue() {
		return this.value;
	}
	public boolean isEven() {
		if ((this.value % 2) == 0)
			return true;
		return false;
	}
	public boolean isOdd() {
		if ((this.value % 2) == 1)
			return true;
		return false;
	}
	public boolean isPrime() {
		for (int i = 2; i <= (this.value / 2); i++) {
			if ((this.value % i) == 0)
				return false;
		}
		return true;
	}
	public boolean equals(int value) {
		if (value == this.value)
			return true;
		return false;
	}
	public boolean equals(MyInteger object) {
		if (object.value == this.value)
			return true;
		return false;
	}
	
	// static
	public static int parseInt(char[] characters) {
		int temp = 0;
		for (int i = 0; i < characters.length; i++) {
			temp += Character.getNumericValue(characters[i]);
			if (i < (characters.length - 1))
				temp *= 10;
		}
		return temp;
	}
	public static int parseInt(String charString) {
		int temp = 0;
		for (int i = 0; i < charString.length(); i++) {
			temp += Integer.parseInt(charString.substring(i, i + 1));
			if (i < (charString.length() - 1))
				temp *= 10;
		}
		return temp;
	}
	
	// static int
	public static boolean isEven(int value) {
		if ((value % 2) == 0)
			return true;
		return false;
	}
	public static boolean isOdd(int value) {
		if ((value % 2) == 1)
			return true;
		return false;
	}
	public static boolean isPrime(int value) {
		for (int i = 2; i <= (value / 2); i++) {
			if ((value % i) == 0)
				return false;
		}
		if (value == 2)
			return false;
		return true;
	}
	
	// static myinteger
	public static boolean isEven(MyInteger object) {
		if ((object.value % 2) == 0)
			return true;
		return false;
	}
	public static boolean isOdd(MyInteger object) {
		if ((object.value % 2) == 1)
			return true;
		return false;
	}
	public static boolean isPrime(MyInteger object) {
		for (int i = 2; i <= (object.value / 2); i++) {
			if ((object.value % i) == 0)
				return false;
		}
		if (object.value == 2)
			return false;
		return true;
	}
}
