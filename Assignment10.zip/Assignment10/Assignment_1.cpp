/*
Application Name: File Character Counter
Assignment Number: Unit 10 Assignment 1
Version: 1.0
Description: The program will use the text file text.txt found in the Unit10 folder as an input file to determine the number of uppercase, 
             lowercase, and digit characters in the file.
Input: None
Output: String, Integer

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 10/27/2022
*/

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
using namespace std;

// Function prototyping
void numUppercaseLetters(ifstream&);
void numLowercaseLetters(ifstream&);
void numDigits(ifstream&);

int main()
{
    // Define and open read file
    ifstream textFile;
    textFile.open("../text.txt");

    // System welcome
    cout << "This is the file character counter program." << endl << endl;

    // Call the three counting functions
    numUppercaseLetters(textFile);
    numLowercaseLetters(textFile);
    numDigits(textFile);

    // Close read file
    textFile.close();
}

// Determine the number of uppercase characters in a text file
void numUppercaseLetters(ifstream& textFile) {
    // Reset file read position to 0
    textFile.clear();
    textFile.seekg(0);
    // Initialize currentWord, wordIndex, and uppercaseCount for storage
    string currentWord = "";
    int wordIndex = 0;
    int uppercaseCount = 0;

    // Scan text document and words for uppercase characters
    while (textFile >> currentWord) {
        do {
            if (isupper(currentWord[wordIndex])) {
                uppercaseCount++;
            }
            wordIndex++;
        } while (wordIndex < (currentWord.size() - 1));
        wordIndex = 0;
    }

    // Display amount of uppercase letters found
    cout << "Found " << uppercaseCount << " uppercase letters in this text file!" << endl;
}

// Determine the number of lowercase characters in a text file
void numLowercaseLetters(ifstream& textFile) {
    // Reset file read position to 0
    textFile.clear();
    textFile.seekg(0);
    // Initialize currentWord, wordIndex, and lowercaseCount for storage
    string currentWord = "";
    int wordIndex = 0;
    int lowercaseCount = 0;

    // Scan text document and words for lowercase characters
    while (textFile >> currentWord) {
        do {
            if (islower(currentWord[wordIndex])) {
                lowercaseCount++;
            }
            wordIndex++;
        } while (wordIndex < (currentWord.size() - 1));
        wordIndex = 0;
    }

    // Display amount of lowercase letters found
    cout << "Found " << lowercaseCount << " lowercase letters in this text file!" << endl;
}

// Determine the number of digits in a text file
void numDigits(ifstream& textFile) {
    // Reset file read position to 0
    textFile.clear();
    textFile.seekg(0);
    // Initialize currentWord, wordIndex, and digitCount for storage
    string currentWord = "";
    int wordIndex = 0;
    int digitCount = 0;

    // Scan text document and words for digits
    while (textFile >> currentWord) {
        do {
            if (isdigit(currentWord[wordIndex])) {
                digitCount++;
            }
            wordIndex++;
        } while (wordIndex < (currentWord.size() - 1));
        wordIndex = 0;
    }

    // Display amount of digits found
    cout << "Found " << digitCount << " digits in this text file!" << endl;
}