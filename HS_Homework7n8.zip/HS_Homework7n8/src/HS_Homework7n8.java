/*
Author: Hunter Sokolis
Date: 10/13/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Program asks user to enter 10 numbers. It will then sort those 10 numbers from least to greatest while displaying
the largest and smallest numbers, the sum, and the average.
 */

import java.util.*;

public class HS_Homework7n8 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		ArrayList<Double> numbers = new ArrayList<Double>();
		double sum = 0.0;
		
		// input
		for (int i = 0; i < 10; i++) {
			System.out.print("Please enter a number: ");
			numbers.add(input.nextDouble());
			sum += numbers.get(i);
		}
		input.close();
		
		// sorting
		int smallestIndex = numbers.size() - 1;
		int sortTracker = 0;
		for (int i = 0; i < numbers.size(); i++) {
			smallestIndex = numbers.size() - 1;
			for (int e = sortTracker; e < numbers.size(); e++) {
				if (numbers.get(e) < numbers.get(smallestIndex)) {
					smallestIndex = e;
				}
			}
			double tempValue = numbers.get(sortTracker);
			numbers.set(i, numbers.get(smallestIndex));
			numbers.set(smallestIndex, tempValue);
			sortTracker++;
		}
		
		// display
		double average = sum / 10;
		System.out.println("Sorted list:");
		for (double number : numbers) {
			System.out.print(number + " ");
		}
		System.out.println("\nLargest = " + numbers.get(9));
		System.out.println("Smallest = " + numbers.get(0));
		System.out.println("Sum = " + sum);
		System.out.println("Average = " + average);
	}
}
