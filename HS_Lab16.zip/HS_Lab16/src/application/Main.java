/*
Author: Hunter Sokolis
Date: 12/10/2023
Instructor: Mariusz Gladys
Course: CIS-2571
Description: Provides four buttons to calculate numbers input in the first two text boxes.
 */

package application;
	
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;


public class Main extends Application {
	private TextField tfNumberOne = new TextField();
	private TextField tfNumberTwo = new TextField();
	private TextField tfResult = new TextField();
	public void start(Stage primaryStage) {
		//to display calculation buttons
		HBox oBox = new HBox();
    	oBox.setSpacing(2);
    	oBox.setAlignment(Pos.CENTER);
    	Button btAdd = new Button("Add");
    	Button btSubtract = new Button("Subtract");
    	Button btMultiply = new Button("Multiply");
    	Button btDivide = new Button("Divide");
    	oBox.getChildren().addAll(btAdd, btSubtract, btMultiply, btDivide);
    	
    	//to display input boxes
    	FlowPane numberPane = new FlowPane();
    	numberPane.setAlignment(Pos.CENTER);
    	BorderPane paneNumberOne = new BorderPane();
    	BorderPane paneNumberTwo = new BorderPane();
    	BorderPane paneResult = new BorderPane();
    	paneNumberOne.setLeft(new Label("Number 1:"));
    	paneNumberTwo.setLeft(new Label("Number 2:"));
    	paneResult.setLeft(new Label("Result:"));
    	
    	paneNumberOne.setRight(tfNumberOne);
    	paneNumberTwo.setRight(tfNumberTwo);
    	paneResult.setRight(tfResult);
    	tfNumberOne.setPrefWidth(90);
    	tfNumberTwo.setPrefWidth(90);
    	tfResult.setPrefWidth(260);
    	numberPane.getChildren().addAll(paneNumberOne, paneNumberTwo, paneResult);
    	
    	btAdd.setOnAction(new AddHandler());
    	btSubtract.setOnAction(new SubtractHandler());
    	btMultiply.setOnAction(new MultiplyHandler());
    	btDivide.setOnAction(new DivideHandler());
    	
    	BorderPane borderPane = new BorderPane();
    	borderPane.setBottom(oBox);
    	BorderPane.setAlignment(oBox, Pos.CENTER);
    	borderPane.setCenter(numberPane);
    	
    	Scene scene = new Scene(borderPane, 300, 300);
    	primaryStage.setTitle("Calculator");
    	primaryStage.setScene(scene);
    	primaryStage.show();
	}
	
	class AddHandler implements EventHandler<ActionEvent> {
    	@Override
    	public void handle(ActionEvent e) {
    		try {
	    		double tempResult = Double.valueOf(tfNumberOne.getText()) + Double.valueOf(tfNumberTwo.getText());
	    		tfResult.setText(String.valueOf(tempResult));
    		}
    		catch (Exception ex) {
    			tfResult.setText("An error occurred. Re-enter both numbers.");
    		}
    	}
    }
	
	class SubtractHandler implements EventHandler<ActionEvent> {
    	@Override
    	public void handle(ActionEvent e) {
    		try {
	    		double tempResult = Double.valueOf(tfNumberOne.getText()) - Double.valueOf(tfNumberTwo.getText());
	    		tfResult.setText(String.valueOf(tempResult));
    		}
    		catch (Exception ex) {
    			tfResult.setText("An error occurred. Re-enter both numbers.");
    		}
    		
    	}
    }
	
	class MultiplyHandler implements EventHandler<ActionEvent> {
    	@Override
    	public void handle(ActionEvent e) {
    		try {
	    		double tempResult = Double.valueOf(tfNumberOne.getText()) * Double.valueOf(tfNumberTwo.getText());
	    		tfResult.setText(String.valueOf(tempResult));
    		}
    		catch (Exception ex) {
    			tfResult.setText("An error occurred. Re-enter both numbers.");
    		}
    	}
    }
	
	class DivideHandler implements EventHandler<ActionEvent> {
    	@Override
    	public void handle(ActionEvent e) {
    		try {
	    		double tempResult = Double.valueOf(tfNumberOne.getText()) / Double.valueOf(tfNumberTwo.getText());
	    		tfResult.setText(String.valueOf(tempResult));
    		}
    		catch (Exception ex) {
    			tfResult.setText("An error occurred. Re-enter both numbers.");
    		}
    	}
    }
	
	public static void main(String[] args) {
		launch(args);
	}
}
