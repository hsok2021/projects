/*
Application Name: Teal County Tax Calculator
Assignment Number: Unit 2 Assignment 1
Version: 1.0
Description: Program will compute the sales tax of a $95 purchase and display output. No user input.
Input: None
Output: Double

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/1/2022
*/

#include <iostream>
using namespace std;

int main()
{
    // Initialization
    const double PRICE = 95.0,
        STATE_TAX = 0.04,
        COUNTY_TAX = 0.02;
    double total;

    // Sales tax calculation
    total = PRICE + (PRICE * STATE_TAX) + (PRICE * COUNTY_TAX);

    // Output
    cout << "The total price of your $95.00 purchase including taxes is $" << total << "." << "\n---";
    return 0;
}