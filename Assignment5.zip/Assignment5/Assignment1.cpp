/*
Application Name: Cross-System Dictionary
Assignment Number: Unit 5 Assignment 1
Version: 1.0
Description: Prompts user for input of minimum and maximum numbers between 1-256 to view dictionary. Outputs different decimal numbers in binary, octal, and
             hexadecimal number systems.
Input: Integer
Output: Integer, Char

Course Name: C++ Language Programming
Course Number: CIS-2541-NET01
Instructor: Mohammad Morovati

Author: Hunter Sokolis
Date: 9/19/2022
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    // Data storage
    int minNum, maxNum;

    // User prompt
    cout << "This is the Cross-System Dictionary." << endl << "It will show you the conversion from the decimal system to the binary, octal, and hexadecimal systems." << endl << endl;
    cout << "Enter the lowest number that you wish to see in a range from 1-256: ";
    cin >> minNum;
    while (minNum <= 0 || minNum >= 257) {
        cout << "Your number is out of bounds. Please enter a number within 1-256. ";
        cin >> minNum;
    }

    cout << "Enter the highest number that you wish to see in a range from 1-256: ";
    cin >> maxNum;
    while (maxNum <= 0 || maxNum >= 257) {
        cout << "Your number is out of bounds. Please enter a number within 1-256. ";
        cin >> maxNum;
    }
    maxNum++;

    // Display decimal
    cout << left;
    cout << "Decimal" << endl << endl;
    int decMin = minNum;
    while (decMin < maxNum) {
        cout << setw(4) << decMin;
        decMin++;
    }

    // Display binary
    cout << endl << endl << "Binary" << endl << endl;
    int binMin = minNum;
    while (binMin < maxNum) {
        int binNum = binMin, binRemainder, toBinary = 0, binNextNum = 1;
        while (binNum != 0) {
            binRemainder = binNum % 2;
            binNum /= 2;
            toBinary += (binRemainder * binNextNum);
            binNextNum *= 10;
        }
        cout << setw(10) << toBinary;
        binMin++;
    }

    // Display Octal
    cout << endl << endl << "Octal" << endl << endl;
    for (int octNum = minNum; octNum < maxNum; octNum++) {
        int toOctal = 0, octCatch = 0;
        for (int i = 0; i < octNum; i++) {
            toOctal++;
            octCatch++;
            if (octCatch == 8) {
                toOctal += 2;
                octCatch = 0;
            }
        }
        cout << setw(4) << toOctal;
    }

    // Display Hexadecimal
    cout << endl << endl << "Hexadecimal" << endl << endl;
    int hexMin = minNum;
    do {
        int intOne = hexMin % 16;
        int intTwo = hexMin / 16;
        char charOne, charTwo;
        switch (intOne) {
        case 10:
            charOne = 'a';
            break;
        case 11:
            charOne = 'b';
            break;
        case 12:
            charOne = 'c';
            break;
        case 13:
            charOne = 'd';
            break;
        case 14:
            charOne = 'e';
            break;
        case 15:
            charOne = 'f';
            break;
        default:
            charOne = static_cast<char>(intOne + 48);
            break;
        }
        switch (intTwo) {
        case 0:
            charTwo = ' ';
            break;
        case 10:
            charTwo = 'a';
            break;
        case 11:
            charTwo = 'b';
            break;
        case 12:
            charTwo = 'c';
            break;
        case 13:
            charTwo = 'd';
            break;
        case 14:
            charTwo = 'e';
            break;
        case 15:
            charTwo = 'f';
            break;
        default:
            charTwo = static_cast<char>(intTwo + 48);
            break;
        }
        if (hexMin == 256) {
            cout << setw(2) << 100;
        }
        else {
            cout << charTwo << setw(2) << charOne;
        }
        hexMin++;
    } while (hexMin < maxNum);

    return 0;
}